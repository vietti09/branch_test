

```python
import numpy as np                   # Data manipulation
import pandas as pd                  # DataFrame manipulation
import time                          # To time processes 
import warnings                      # To suppress warnings
import matplotlib.pyplot as plt      # For Graphics
import seaborn as sns
from sklearn import cluster, mixture # For clustering 
from sklearn.preprocessing import StandardScaler

import plotly.graph_objs as go
from plotly.offline import download_plotlyjs, init_notebook_mode, plot, iplot
init_notebook_mode(connected=True)
%matplotlib inline
warnings.filterwarnings('ignore')
```


<script>requirejs.config({paths: { 'plotly': ['https://cdn.plot.ly/plotly-latest.min']},});if(!window.Plotly) {{require(['plotly'],function(plotly) {window.Plotly=plotly;});}}</script>



```python
file = "API_NY.GDP.MKTP.CD_DS2_en_csv_v2.csv"
df = pd.read_csv(file, sep=",", encoding='cp1252')
df.head()

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Country Name</th>
      <th>Country Code</th>
      <th>Indicator Name</th>
      <th>Indicator Code</th>
      <th>1959</th>
      <th>1960</th>
      <th>1961</th>
      <th>1962</th>
      <th>1963</th>
      <th>1964</th>
      <th>...</th>
      <th>2008</th>
      <th>2009</th>
      <th>2010</th>
      <th>2011</th>
      <th>2012</th>
      <th>2013</th>
      <th>2014</th>
      <th>2015</th>
      <th>2016</th>
      <th>2017</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Aruba</td>
      <td>ABW</td>
      <td>GDP (current US$)</td>
      <td>NY.GDP.MKTP.CD</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>2.791961e+09</td>
      <td>2.498933e+09</td>
      <td>2.467704e+09</td>
      <td>2.584464e+09</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Afghanistan</td>
      <td>AFG</td>
      <td>GDP (current US$)</td>
      <td>NY.GDP.MKTP.CD</td>
      <td>NaN</td>
      <td>537777811.1</td>
      <td>548888895.6</td>
      <td>546666677.8</td>
      <td>751111191.1</td>
      <td>800000044.4</td>
      <td>...</td>
      <td>1.019053e+10</td>
      <td>1.248694e+10</td>
      <td>1.593680e+10</td>
      <td>1.793024e+10</td>
      <td>2.053654e+10</td>
      <td>2.026425e+10</td>
      <td>2.061610e+10</td>
      <td>1.921556e+10</td>
      <td>1.946902e+10</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Angola</td>
      <td>AGO</td>
      <td>GDP (current US$)</td>
      <td>NY.GDP.MKTP.CD</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>8.417803e+10</td>
      <td>7.549238e+10</td>
      <td>8.247091e+10</td>
      <td>1.040000e+11</td>
      <td>1.150000e+11</td>
      <td>1.250000e+11</td>
      <td>1.270000e+11</td>
      <td>1.030000e+11</td>
      <td>9.533511e+10</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Albania</td>
      <td>ALB</td>
      <td>GDP (current US$)</td>
      <td>NY.GDP.MKTP.CD</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>1.288135e+10</td>
      <td>1.204421e+10</td>
      <td>1.192695e+10</td>
      <td>1.289087e+10</td>
      <td>1.231978e+10</td>
      <td>1.277628e+10</td>
      <td>1.322824e+10</td>
      <td>1.133526e+10</td>
      <td>1.186387e+10</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Andorra</td>
      <td>AND</td>
      <td>GDP (current US$)</td>
      <td>NY.GDP.MKTP.CD</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>4.007353e+09</td>
      <td>3.660531e+09</td>
      <td>3.355695e+09</td>
      <td>3.442063e+09</td>
      <td>3.164615e+09</td>
      <td>3.281585e+09</td>
      <td>3.350736e+09</td>
      <td>2.811489e+09</td>
      <td>2.858518e+09</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 63 columns</p>
</div>




```python
df = df[["Country Name", "2015", "2016"]]
```


```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Country Name</th>
      <th>2015</th>
      <th>2016</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Aruba</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Afghanistan</td>
      <td>1.921556e+10</td>
      <td>1.946902e+10</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Angola</td>
      <td>1.030000e+11</td>
      <td>9.533511e+10</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Albania</td>
      <td>1.133526e+10</td>
      <td>1.186387e+10</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Andorra</td>
      <td>2.811489e+09</td>
      <td>2.858518e+09</td>
    </tr>
  </tbody>
</table>
</div>




```python
GDP=df.fillna(value=0)
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Country Name</th>
      <th>2015</th>
      <th>2016</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Aruba</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Afghanistan</td>
      <td>1.921556e+10</td>
      <td>1.946902e+10</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Angola</td>
      <td>1.030000e+11</td>
      <td>9.533511e+10</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Albania</td>
      <td>1.133526e+10</td>
      <td>1.186387e+10</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Andorra</td>
      <td>2.811489e+09</td>
      <td>2.858518e+09</td>
    </tr>
  </tbody>
</table>
</div>




```python
file2 = "happiness.csv"
df2= pd.read_csv(file2)
```


```python
df2.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Unnamed: 0</th>
      <th>Country Name</th>
      <th>Happiness Rank 2015</th>
      <th>Happiness Score 2015</th>
      <th>Happiness Rank 2016</th>
      <th>Happiness Score 2016</th>
      <th>GDP(billions) 2015</th>
      <th>GDP, 2016 (billions)</th>
      <th>Total Population 2015</th>
      <th>Total Population 2016</th>
      <th>GDP/Pop 2015</th>
      <th>GDP/Pop 2016</th>
      <th>GDI 2015</th>
      <th>GDI 2016</th>
      <th>GDI/Pop 2015</th>
      <th>GDI/Pop 2016</th>
      <th>CPI 2015</th>
      <th>CPI 2016</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>Switzerland</td>
      <td>1</td>
      <td>7.587</td>
      <td>2</td>
      <td>7.509</td>
      <td>679.00</td>
      <td>669.0</td>
      <td>8282.40</td>
      <td>8372.41</td>
      <td>81.981068</td>
      <td>79.905308</td>
      <td>6.673750e+11</td>
      <td>6.656087e+11</td>
      <td>8.057749e+07</td>
      <td>7.950025e+07</td>
      <td>100.617575</td>
      <td>100.180283</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>Iceland</td>
      <td>2</td>
      <td>7.561</td>
      <td>3</td>
      <td>7.501</td>
      <td>16.94</td>
      <td>20.3</td>
      <td>330.82</td>
      <td>335.44</td>
      <td>51.206094</td>
      <td>60.517529</td>
      <td>1.891027e+12</td>
      <td>2.063429e+12</td>
      <td>5.716182e+09</td>
      <td>6.151410e+09</td>
      <td>239.815158</td>
      <td>243.876225</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2</td>
      <td>Denmark</td>
      <td>3</td>
      <td>7.527</td>
      <td>1</td>
      <td>7.526</td>
      <td>301.00</td>
      <td>307.0</td>
      <td>5683.48</td>
      <td>5728.01</td>
      <td>52.960510</td>
      <td>53.596275</td>
      <td>1.928783e+12</td>
      <td>1.958050e+12</td>
      <td>3.393665e+08</td>
      <td>3.418377e+08</td>
      <td>100.000000</td>
      <td>100.250000</td>
    </tr>
    <tr>
      <th>3</th>
      <td>3</td>
      <td>Norway</td>
      <td>4</td>
      <td>7.522</td>
      <td>4</td>
      <td>7.498</td>
      <td>387.00</td>
      <td>371.0</td>
      <td>5190.24</td>
      <td>5236.15</td>
      <td>74.563026</td>
      <td>70.853585</td>
      <td>2.739875e+12</td>
      <td>2.682282e+12</td>
      <td>5.278899e+08</td>
      <td>5.122622e+08</td>
      <td>100.000000</td>
      <td>103.550000</td>
    </tr>
    <tr>
      <th>4</th>
      <td>4</td>
      <td>Canada</td>
      <td>5</td>
      <td>7.427</td>
      <td>6</td>
      <td>7.404</td>
      <td>1560.00</td>
      <td>1540.0</td>
      <td>35832.51</td>
      <td>36264.60</td>
      <td>43.535884</td>
      <td>42.465655</td>
      <td>1.819117e+12</td>
      <td>1.834327e+12</td>
      <td>5.076722e+07</td>
      <td>5.058176e+07</td>
      <td>126.566667</td>
      <td>128.375000</td>
    </tr>
  </tbody>
</table>
</div>




```python
happiness = df2[["Country Name", "Happiness Rank 2015", "Happiness Rank 2016", "Happiness Score 2015", "Happiness Score 2016"]]
happiness.head()

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Country Name</th>
      <th>Happiness Rank 2015</th>
      <th>Happiness Rank 2016</th>
      <th>Happiness Score 2015</th>
      <th>Happiness Score 2016</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Switzerland</td>
      <td>1</td>
      <td>2</td>
      <td>7.587</td>
      <td>7.509</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Iceland</td>
      <td>2</td>
      <td>3</td>
      <td>7.561</td>
      <td>7.501</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Denmark</td>
      <td>3</td>
      <td>1</td>
      <td>7.527</td>
      <td>7.526</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Norway</td>
      <td>4</td>
      <td>4</td>
      <td>7.522</td>
      <td>7.498</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Canada</td>
      <td>5</td>
      <td>6</td>
      <td>7.427</td>
      <td>7.404</td>
    </tr>
  </tbody>
</table>
</div>




```python
Final_happiness = pd.merge(happiness, GDP, on="Country Name", how = "inner")
Final_happiness
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Country Name</th>
      <th>Happiness Rank 2015</th>
      <th>Happiness Rank 2016</th>
      <th>Happiness Score 2015</th>
      <th>Happiness Score 2016</th>
      <th>2015</th>
      <th>2016</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Switzerland</td>
      <td>1</td>
      <td>2</td>
      <td>7.587</td>
      <td>7.509</td>
      <td>6.790000e+11</td>
      <td>6.690000e+11</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Iceland</td>
      <td>2</td>
      <td>3</td>
      <td>7.561</td>
      <td>7.501</td>
      <td>1.694225e+10</td>
      <td>2.030410e+10</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Denmark</td>
      <td>3</td>
      <td>1</td>
      <td>7.527</td>
      <td>7.526</td>
      <td>3.010000e+11</td>
      <td>3.070000e+11</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Norway</td>
      <td>4</td>
      <td>4</td>
      <td>7.522</td>
      <td>7.498</td>
      <td>3.870000e+11</td>
      <td>3.710000e+11</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Canada</td>
      <td>5</td>
      <td>6</td>
      <td>7.427</td>
      <td>7.404</td>
      <td>1.560000e+12</td>
      <td>1.540000e+12</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Netherlands</td>
      <td>7</td>
      <td>7</td>
      <td>7.378</td>
      <td>7.339</td>
      <td>7.580000e+11</td>
      <td>7.770000e+11</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Sweden</td>
      <td>8</td>
      <td>10</td>
      <td>7.364</td>
      <td>7.291</td>
      <td>4.980000e+11</td>
      <td>5.140000e+11</td>
    </tr>
    <tr>
      <th>7</th>
      <td>New Zealand</td>
      <td>9</td>
      <td>8</td>
      <td>7.286</td>
      <td>7.334</td>
      <td>1.760000e+11</td>
      <td>1.850000e+11</td>
    </tr>
    <tr>
      <th>8</th>
      <td>Australia</td>
      <td>10</td>
      <td>9</td>
      <td>7.284</td>
      <td>7.313</td>
      <td>1.350000e+12</td>
      <td>1.200000e+12</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Israel</td>
      <td>11</td>
      <td>11</td>
      <td>7.278</td>
      <td>7.267</td>
      <td>2.990000e+11</td>
      <td>3.180000e+11</td>
    </tr>
    <tr>
      <th>10</th>
      <td>Costa Rica</td>
      <td>12</td>
      <td>14</td>
      <td>7.226</td>
      <td>7.087</td>
      <td>5.484010e+10</td>
      <td>5.743551e+10</td>
    </tr>
    <tr>
      <th>11</th>
      <td>Austria</td>
      <td>13</td>
      <td>12</td>
      <td>7.200</td>
      <td>7.119</td>
      <td>3.820000e+11</td>
      <td>3.910000e+11</td>
    </tr>
    <tr>
      <th>12</th>
      <td>Mexico</td>
      <td>14</td>
      <td>21</td>
      <td>7.187</td>
      <td>6.778</td>
      <td>1.150000e+12</td>
      <td>1.050000e+12</td>
    </tr>
    <tr>
      <th>13</th>
      <td>United States</td>
      <td>15</td>
      <td>13</td>
      <td>7.119</td>
      <td>7.104</td>
      <td>1.810000e+13</td>
      <td>1.860000e+13</td>
    </tr>
    <tr>
      <th>14</th>
      <td>Brazil</td>
      <td>16</td>
      <td>17</td>
      <td>6.983</td>
      <td>6.952</td>
      <td>1.800000e+12</td>
      <td>1.800000e+12</td>
    </tr>
    <tr>
      <th>15</th>
      <td>Luxembourg</td>
      <td>17</td>
      <td>20</td>
      <td>6.946</td>
      <td>6.871</td>
      <td>5.778450e+10</td>
      <td>5.863132e+10</td>
    </tr>
    <tr>
      <th>16</th>
      <td>Ireland</td>
      <td>18</td>
      <td>19</td>
      <td>6.940</td>
      <td>6.907</td>
      <td>2.910000e+11</td>
      <td>3.050000e+11</td>
    </tr>
    <tr>
      <th>17</th>
      <td>Belgium</td>
      <td>19</td>
      <td>18</td>
      <td>6.937</td>
      <td>6.929</td>
      <td>4.550000e+11</td>
      <td>4.680000e+11</td>
    </tr>
    <tr>
      <th>18</th>
      <td>United Kingdom</td>
      <td>21</td>
      <td>23</td>
      <td>6.867</td>
      <td>6.725</td>
      <td>2.890000e+12</td>
      <td>2.650000e+12</td>
    </tr>
    <tr>
      <th>19</th>
      <td>Singapore</td>
      <td>24</td>
      <td>22</td>
      <td>6.798</td>
      <td>6.739</td>
      <td>2.970000e+11</td>
      <td>2.970000e+11</td>
    </tr>
    <tr>
      <th>20</th>
      <td>Panama</td>
      <td>25</td>
      <td>25</td>
      <td>6.786</td>
      <td>6.701</td>
      <td>5.213229e+10</td>
      <td>5.518770e+10</td>
    </tr>
    <tr>
      <th>21</th>
      <td>Germany</td>
      <td>26</td>
      <td>16</td>
      <td>6.750</td>
      <td>6.994</td>
      <td>3.380000e+12</td>
      <td>3.480000e+12</td>
    </tr>
    <tr>
      <th>22</th>
      <td>Chile</td>
      <td>27</td>
      <td>24</td>
      <td>6.670</td>
      <td>6.705</td>
      <td>2.430000e+11</td>
      <td>2.470000e+11</td>
    </tr>
    <tr>
      <th>23</th>
      <td>Qatar</td>
      <td>28</td>
      <td>36</td>
      <td>6.611</td>
      <td>6.375</td>
      <td>1.650000e+11</td>
      <td>1.520000e+11</td>
    </tr>
    <tr>
      <th>24</th>
      <td>France</td>
      <td>29</td>
      <td>32</td>
      <td>6.575</td>
      <td>6.478</td>
      <td>2.430000e+12</td>
      <td>2.470000e+12</td>
    </tr>
    <tr>
      <th>25</th>
      <td>Czech Republic</td>
      <td>31</td>
      <td>27</td>
      <td>6.505</td>
      <td>6.596</td>
      <td>1.870000e+11</td>
      <td>1.950000e+11</td>
    </tr>
    <tr>
      <th>26</th>
      <td>Uruguay</td>
      <td>32</td>
      <td>29</td>
      <td>6.485</td>
      <td>6.545</td>
      <td>5.327430e+10</td>
      <td>5.241972e+10</td>
    </tr>
    <tr>
      <th>27</th>
      <td>Colombia</td>
      <td>33</td>
      <td>31</td>
      <td>6.477</td>
      <td>6.481</td>
      <td>2.920000e+11</td>
      <td>2.820000e+11</td>
    </tr>
    <tr>
      <th>28</th>
      <td>Thailand</td>
      <td>34</td>
      <td>33</td>
      <td>6.455</td>
      <td>6.474</td>
      <td>3.990000e+11</td>
      <td>4.070000e+11</td>
    </tr>
    <tr>
      <th>29</th>
      <td>Saudi Arabia</td>
      <td>35</td>
      <td>34</td>
      <td>6.411</td>
      <td>6.379</td>
      <td>6.520000e+11</td>
      <td>6.460000e+11</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>57</th>
      <td>Latvia</td>
      <td>89</td>
      <td>68</td>
      <td>5.098</td>
      <td>5.560</td>
      <td>2.697286e+10</td>
      <td>2.757270e+10</td>
    </tr>
    <tr>
      <th>58</th>
      <td>Philippines</td>
      <td>90</td>
      <td>82</td>
      <td>5.073</td>
      <td>5.279</td>
      <td>2.930000e+11</td>
      <td>3.050000e+11</td>
    </tr>
    <tr>
      <th>59</th>
      <td>Morocco</td>
      <td>92</td>
      <td>90</td>
      <td>5.013</td>
      <td>5.151</td>
      <td>1.010000e+11</td>
      <td>1.040000e+11</td>
    </tr>
    <tr>
      <th>60</th>
      <td>Bosnia and Herzegovina</td>
      <td>96</td>
      <td>87</td>
      <td>4.949</td>
      <td>5.163</td>
      <td>1.620970e+10</td>
      <td>1.691028e+10</td>
    </tr>
    <tr>
      <th>61</th>
      <td>Dominican Republic</td>
      <td>98</td>
      <td>89</td>
      <td>4.885</td>
      <td>5.155</td>
      <td>6.810262e+10</td>
      <td>7.158355e+10</td>
    </tr>
    <tr>
      <th>62</th>
      <td>Mongolia</td>
      <td>100</td>
      <td>101</td>
      <td>4.874</td>
      <td>4.907</td>
      <td>1.174962e+10</td>
      <td>1.118346e+10</td>
    </tr>
    <tr>
      <th>63</th>
      <td>Greece</td>
      <td>102</td>
      <td>99</td>
      <td>4.857</td>
      <td>5.033</td>
      <td>1.960000e+11</td>
      <td>1.930000e+11</td>
    </tr>
    <tr>
      <th>64</th>
      <td>Hungary</td>
      <td>104</td>
      <td>91</td>
      <td>4.800</td>
      <td>5.145</td>
      <td>1.230000e+11</td>
      <td>1.260000e+11</td>
    </tr>
    <tr>
      <th>65</th>
      <td>Honduras</td>
      <td>105</td>
      <td>104</td>
      <td>4.788</td>
      <td>4.871</td>
      <td>2.084428e+10</td>
      <td>2.151694e+10</td>
    </tr>
    <tr>
      <th>66</th>
      <td>Tunisia</td>
      <td>107</td>
      <td>98</td>
      <td>4.739</td>
      <td>5.045</td>
      <td>4.315671e+10</td>
      <td>4.206255e+10</td>
    </tr>
    <tr>
      <th>67</th>
      <td>Ukraine</td>
      <td>111</td>
      <td>123</td>
      <td>4.681</td>
      <td>4.324</td>
      <td>9.103096e+10</td>
      <td>9.327048e+10</td>
    </tr>
    <tr>
      <th>68</th>
      <td>South Africa</td>
      <td>113</td>
      <td>116</td>
      <td>4.642</td>
      <td>4.459</td>
      <td>3.180000e+11</td>
      <td>2.950000e+11</td>
    </tr>
    <tr>
      <th>69</th>
      <td>Ghana</td>
      <td>114</td>
      <td>124</td>
      <td>4.633</td>
      <td>4.276</td>
      <td>3.754336e+10</td>
      <td>4.268978e+10</td>
    </tr>
    <tr>
      <th>70</th>
      <td>Zimbabwe</td>
      <td>115</td>
      <td>131</td>
      <td>4.610</td>
      <td>4.193</td>
      <td>1.630467e+10</td>
      <td>1.661996e+10</td>
    </tr>
    <tr>
      <th>71</th>
      <td>Liberia</td>
      <td>116</td>
      <td>150</td>
      <td>4.571</td>
      <td>3.622</td>
      <td>2.034000e+09</td>
      <td>2.101000e+09</td>
    </tr>
    <tr>
      <th>72</th>
      <td>India</td>
      <td>117</td>
      <td>118</td>
      <td>4.565</td>
      <td>4.404</td>
      <td>2.090000e+12</td>
      <td>2.260000e+12</td>
    </tr>
    <tr>
      <th>73</th>
      <td>Nepal</td>
      <td>121</td>
      <td>107</td>
      <td>4.514</td>
      <td>4.793</td>
      <td>2.141084e+10</td>
      <td>2.113198e+10</td>
    </tr>
    <tr>
      <th>74</th>
      <td>Ethiopia</td>
      <td>122</td>
      <td>115</td>
      <td>4.512</td>
      <td>4.508</td>
      <td>6.446455e+10</td>
      <td>7.237422e+10</td>
    </tr>
    <tr>
      <th>75</th>
      <td>Sierra Leone</td>
      <td>123</td>
      <td>111</td>
      <td>4.507</td>
      <td>4.635</td>
      <td>4.251870e+09</td>
      <td>3.736589e+09</td>
    </tr>
    <tr>
      <th>76</th>
      <td>Mauritania</td>
      <td>124</td>
      <td>130</td>
      <td>4.436</td>
      <td>4.201</td>
      <td>4.844223e+09</td>
      <td>4.739299e+09</td>
    </tr>
    <tr>
      <th>77</th>
      <td>Kenya</td>
      <td>125</td>
      <td>122</td>
      <td>4.419</td>
      <td>4.356</td>
      <td>6.376754e+10</td>
      <td>7.052901e+10</td>
    </tr>
    <tr>
      <th>78</th>
      <td>Georgia</td>
      <td>130</td>
      <td>126</td>
      <td>4.297</td>
      <td>4.252</td>
      <td>1.399355e+10</td>
      <td>1.437802e+10</td>
    </tr>
    <tr>
      <th>79</th>
      <td>Malawi</td>
      <td>131</td>
      <td>132</td>
      <td>4.292</td>
      <td>4.156</td>
      <td>6.373201e+09</td>
      <td>5.433039e+09</td>
    </tr>
    <tr>
      <th>80</th>
      <td>Sri Lanka</td>
      <td>132</td>
      <td>117</td>
      <td>4.271</td>
      <td>4.415</td>
      <td>8.061199e+10</td>
      <td>8.132188e+10</td>
    </tr>
    <tr>
      <th>81</th>
      <td>Bulgaria</td>
      <td>134</td>
      <td>129</td>
      <td>4.218</td>
      <td>4.217</td>
      <td>5.019912e+10</td>
      <td>5.323788e+10</td>
    </tr>
    <tr>
      <th>82</th>
      <td>Senegal</td>
      <td>142</td>
      <td>128</td>
      <td>3.904</td>
      <td>4.219</td>
      <td>1.364067e+10</td>
      <td>1.468370e+10</td>
    </tr>
    <tr>
      <th>83</th>
      <td>Gabon</td>
      <td>143</td>
      <td>134</td>
      <td>3.896</td>
      <td>4.121</td>
      <td>1.426203e+10</td>
      <td>1.421356e+10</td>
    </tr>
    <tr>
      <th>84</th>
      <td>Tanzania</td>
      <td>146</td>
      <td>149</td>
      <td>3.781</td>
      <td>3.666</td>
      <td>4.562832e+10</td>
      <td>4.734007e+10</td>
    </tr>
    <tr>
      <th>85</th>
      <td>Rwanda</td>
      <td>154</td>
      <td>152</td>
      <td>3.465</td>
      <td>3.515</td>
      <td>8.261034e+09</td>
      <td>8.376049e+09</td>
    </tr>
    <tr>
      <th>86</th>
      <td>Benin</td>
      <td>155</td>
      <td>153</td>
      <td>3.340</td>
      <td>3.484</td>
      <td>8.290987e+09</td>
      <td>8.583031e+09</td>
    </tr>
  </tbody>
</table>
<p>87 rows × 7 columns</p>
</div>




```python
file3 = "API_SP.POP.TOTL_DS2_en_csv_v2.csv"
population = pd.read_csv(file3, sep=",", encoding='cp1252', header =2)
population
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Country Name</th>
      <th>Country Code</th>
      <th>Indicator Name</th>
      <th>Indicator Code</th>
      <th>1960</th>
      <th>1961</th>
      <th>1962</th>
      <th>1963</th>
      <th>1964</th>
      <th>1965</th>
      <th>...</th>
      <th>2009</th>
      <th>2010</th>
      <th>2011</th>
      <th>2012</th>
      <th>2013</th>
      <th>2014</th>
      <th>2015</th>
      <th>2016</th>
      <th>2017</th>
      <th>Unnamed: 62</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Aruba</td>
      <td>ABW</td>
      <td>Population, total</td>
      <td>SP.POP.TOTL</td>
      <td>5.421100e+04</td>
      <td>5.543800e+04</td>
      <td>5.622500e+04</td>
      <td>5.669500e+04</td>
      <td>5.703200e+04</td>
      <td>5.736000e+04</td>
      <td>...</td>
      <td>1.014530e+05</td>
      <td>1.016690e+05</td>
      <td>1.020530e+05</td>
      <td>1.025770e+05</td>
      <td>1.031870e+05</td>
      <td>1.037950e+05</td>
      <td>1.043410e+05</td>
      <td>1.048220e+05</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Afghanistan</td>
      <td>AFG</td>
      <td>Population, total</td>
      <td>SP.POP.TOTL</td>
      <td>8.996351e+06</td>
      <td>9.166764e+06</td>
      <td>9.345868e+06</td>
      <td>9.533954e+06</td>
      <td>9.731361e+06</td>
      <td>9.938414e+06</td>
      <td>...</td>
      <td>2.800433e+07</td>
      <td>2.880317e+07</td>
      <td>2.970860e+07</td>
      <td>3.069696e+07</td>
      <td>3.173169e+07</td>
      <td>3.275802e+07</td>
      <td>3.373649e+07</td>
      <td>3.465603e+07</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Angola</td>
      <td>AGO</td>
      <td>Population, total</td>
      <td>SP.POP.TOTL</td>
      <td>5.643182e+06</td>
      <td>5.753024e+06</td>
      <td>5.866061e+06</td>
      <td>5.980417e+06</td>
      <td>6.093321e+06</td>
      <td>6.203299e+06</td>
      <td>...</td>
      <td>2.254955e+07</td>
      <td>2.336913e+07</td>
      <td>2.421856e+07</td>
      <td>2.509615e+07</td>
      <td>2.599834e+07</td>
      <td>2.692047e+07</td>
      <td>2.785930e+07</td>
      <td>2.881346e+07</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Albania</td>
      <td>ALB</td>
      <td>Population, total</td>
      <td>SP.POP.TOTL</td>
      <td>1.608800e+06</td>
      <td>1.659800e+06</td>
      <td>1.711319e+06</td>
      <td>1.762621e+06</td>
      <td>1.814135e+06</td>
      <td>1.864791e+06</td>
      <td>...</td>
      <td>2.927519e+06</td>
      <td>2.913021e+06</td>
      <td>2.905195e+06</td>
      <td>2.900401e+06</td>
      <td>2.895092e+06</td>
      <td>2.889104e+06</td>
      <td>2.880703e+06</td>
      <td>2.876101e+06</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Andorra</td>
      <td>AND</td>
      <td>Population, total</td>
      <td>SP.POP.TOTL</td>
      <td>1.341100e+04</td>
      <td>1.437500e+04</td>
      <td>1.537000e+04</td>
      <td>1.641200e+04</td>
      <td>1.746900e+04</td>
      <td>1.854900e+04</td>
      <td>...</td>
      <td>8.446200e+04</td>
      <td>8.444900e+04</td>
      <td>8.375100e+04</td>
      <td>8.243100e+04</td>
      <td>8.078800e+04</td>
      <td>7.922300e+04</td>
      <td>7.801400e+04</td>
      <td>7.728100e+04</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Arab World</td>
      <td>ARB</td>
      <td>Population, total</td>
      <td>SP.POP.TOTL</td>
      <td>9.249093e+07</td>
      <td>9.504450e+07</td>
      <td>9.768229e+07</td>
      <td>1.004111e+08</td>
      <td>1.032399e+08</td>
      <td>1.061750e+08</td>
      <td>...</td>
      <td>3.481451e+08</td>
      <td>3.565089e+08</td>
      <td>3.648959e+08</td>
      <td>3.733070e+08</td>
      <td>3.817021e+08</td>
      <td>3.900430e+08</td>
      <td>3.983050e+08</td>
      <td>4.064527e+08</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>6</th>
      <td>United Arab Emirates</td>
      <td>ARE</td>
      <td>Population, total</td>
      <td>SP.POP.TOTL</td>
      <td>9.263400e+04</td>
      <td>1.010780e+05</td>
      <td>1.124720e+05</td>
      <td>1.255660e+05</td>
      <td>1.385290e+05</td>
      <td>1.503620e+05</td>
      <td>...</td>
      <td>7.666393e+06</td>
      <td>8.270684e+06</td>
      <td>8.672475e+06</td>
      <td>8.900453e+06</td>
      <td>9.006263e+06</td>
      <td>9.070867e+06</td>
      <td>9.154302e+06</td>
      <td>9.269612e+06</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>7</th>
      <td>Argentina</td>
      <td>ARG</td>
      <td>Population, total</td>
      <td>SP.POP.TOTL</td>
      <td>2.061908e+07</td>
      <td>2.095308e+07</td>
      <td>2.128768e+07</td>
      <td>2.162184e+07</td>
      <td>2.195393e+07</td>
      <td>2.228339e+07</td>
      <td>...</td>
      <td>4.079941e+07</td>
      <td>4.122389e+07</td>
      <td>4.165688e+07</td>
      <td>4.209674e+07</td>
      <td>4.253992e+07</td>
      <td>4.298152e+07</td>
      <td>4.341776e+07</td>
      <td>4.384743e+07</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>8</th>
      <td>Armenia</td>
      <td>ARM</td>
      <td>Population, total</td>
      <td>SP.POP.TOTL</td>
      <td>1.874120e+06</td>
      <td>1.941491e+06</td>
      <td>2.009526e+06</td>
      <td>2.077575e+06</td>
      <td>2.144998e+06</td>
      <td>2.211316e+06</td>
      <td>...</td>
      <td>2.888584e+06</td>
      <td>2.877311e+06</td>
      <td>2.875581e+06</td>
      <td>2.881922e+06</td>
      <td>2.893509e+06</td>
      <td>2.906220e+06</td>
      <td>2.916950e+06</td>
      <td>2.924816e+06</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>9</th>
      <td>American Samoa</td>
      <td>ASM</td>
      <td>Population, total</td>
      <td>SP.POP.TOTL</td>
      <td>2.001300e+04</td>
      <td>2.048600e+04</td>
      <td>2.111700e+04</td>
      <td>2.188200e+04</td>
      <td>2.269800e+04</td>
      <td>2.352000e+04</td>
      <td>...</td>
      <td>5.622700e+04</td>
      <td>5.563700e+04</td>
      <td>5.532000e+04</td>
      <td>5.523000e+04</td>
      <td>5.530700e+04</td>
      <td>5.543700e+04</td>
      <td>5.553700e+04</td>
      <td>5.559900e+04</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>10</th>
      <td>Antigua and Barbuda</td>
      <td>ATG</td>
      <td>Population, total</td>
      <td>SP.POP.TOTL</td>
      <td>5.533900e+04</td>
      <td>5.614400e+04</td>
      <td>5.714400e+04</td>
      <td>5.829400e+04</td>
      <td>5.952400e+04</td>
      <td>6.078100e+04</td>
      <td>...</td>
      <td>9.358100e+04</td>
      <td>9.466100e+04</td>
      <td>9.571900e+04</td>
      <td>9.677700e+04</td>
      <td>9.782400e+04</td>
      <td>9.887500e+04</td>
      <td>9.992300e+04</td>
      <td>1.009630e+05</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>11</th>
      <td>Australia</td>
      <td>AUS</td>
      <td>Population, total</td>
      <td>SP.POP.TOTL</td>
      <td>1.027648e+07</td>
      <td>1.048300e+07</td>
      <td>1.074200e+07</td>
      <td>1.095000e+07</td>
      <td>1.116700e+07</td>
      <td>1.138800e+07</td>
      <td>...</td>
      <td>2.169170e+07</td>
      <td>2.203175e+07</td>
      <td>2.234002e+07</td>
      <td>2.274248e+07</td>
      <td>2.314590e+07</td>
      <td>2.350414e+07</td>
      <td>2.385078e+07</td>
      <td>2.421081e+07</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>12</th>
      <td>Austria</td>
      <td>AUT</td>
      <td>Population, total</td>
      <td>SP.POP.TOTL</td>
      <td>7.047539e+06</td>
      <td>7.086299e+06</td>
      <td>7.129864e+06</td>
      <td>7.175811e+06</td>
      <td>7.223801e+06</td>
      <td>7.270889e+06</td>
      <td>...</td>
      <td>8.343323e+06</td>
      <td>8.363404e+06</td>
      <td>8.391643e+06</td>
      <td>8.429991e+06</td>
      <td>8.479375e+06</td>
      <td>8.541575e+06</td>
      <td>8.633169e+06</td>
      <td>8.731471e+06</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>13</th>
      <td>Azerbaijan</td>
      <td>AZE</td>
      <td>Population, total</td>
      <td>SP.POP.TOTL</td>
      <td>3.895396e+06</td>
      <td>4.030320e+06</td>
      <td>4.171425e+06</td>
      <td>4.315128e+06</td>
      <td>4.456689e+06</td>
      <td>4.592610e+06</td>
      <td>...</td>
      <td>8.947243e+06</td>
      <td>9.054332e+06</td>
      <td>9.173082e+06</td>
      <td>9.295784e+06</td>
      <td>9.416801e+06</td>
      <td>9.535079e+06</td>
      <td>9.649341e+06</td>
      <td>9.757812e+06</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>14</th>
      <td>Burundi</td>
      <td>BDI</td>
      <td>Population, total</td>
      <td>SP.POP.TOTL</td>
      <td>2.786106e+06</td>
      <td>2.839666e+06</td>
      <td>2.893669e+06</td>
      <td>2.949926e+06</td>
      <td>3.010859e+06</td>
      <td>3.077876e+06</td>
      <td>...</td>
      <td>8.489031e+06</td>
      <td>8.766930e+06</td>
      <td>9.043508e+06</td>
      <td>9.319710e+06</td>
      <td>9.600186e+06</td>
      <td>9.891790e+06</td>
      <td>1.019927e+07</td>
      <td>1.052412e+07</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>15</th>
      <td>Belgium</td>
      <td>BEL</td>
      <td>Population, total</td>
      <td>SP.POP.TOTL</td>
      <td>9.153489e+06</td>
      <td>9.183948e+06</td>
      <td>9.220578e+06</td>
      <td>9.289770e+06</td>
      <td>9.378113e+06</td>
      <td>9.463667e+06</td>
      <td>...</td>
      <td>1.079649e+07</td>
      <td>1.089559e+07</td>
      <td>1.104774e+07</td>
      <td>1.112825e+07</td>
      <td>1.118282e+07</td>
      <td>1.120906e+07</td>
      <td>1.127420e+07</td>
      <td>1.133848e+07</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>16</th>
      <td>Benin</td>
      <td>BEN</td>
      <td>Population, total</td>
      <td>SP.POP.TOTL</td>
      <td>2.431622e+06</td>
      <td>2.465867e+06</td>
      <td>2.502896e+06</td>
      <td>2.542859e+06</td>
      <td>2.585965e+06</td>
      <td>2.632356e+06</td>
      <td>...</td>
      <td>8.944706e+06</td>
      <td>9.199259e+06</td>
      <td>9.460802e+06</td>
      <td>9.729160e+06</td>
      <td>1.000445e+07</td>
      <td>1.028671e+07</td>
      <td>1.057595e+07</td>
      <td>1.087230e+07</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>17</th>
      <td>Burkina Faso</td>
      <td>BFA</td>
      <td>Population, total</td>
      <td>SP.POP.TOTL</td>
      <td>4.829288e+06</td>
      <td>4.894580e+06</td>
      <td>4.960326e+06</td>
      <td>5.027821e+06</td>
      <td>5.098890e+06</td>
      <td>5.174870e+06</td>
      <td>...</td>
      <td>1.514110e+07</td>
      <td>1.560522e+07</td>
      <td>1.608190e+07</td>
      <td>1.657122e+07</td>
      <td>1.707272e+07</td>
      <td>1.758598e+07</td>
      <td>1.811062e+07</td>
      <td>1.864643e+07</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>18</th>
      <td>Bangladesh</td>
      <td>BGD</td>
      <td>Population, total</td>
      <td>SP.POP.TOTL</td>
      <td>4.819975e+07</td>
      <td>4.959280e+07</td>
      <td>5.103014e+07</td>
      <td>5.253242e+07</td>
      <td>5.412910e+07</td>
      <td>5.583404e+07</td>
      <td>...</td>
      <td>1.504547e+08</td>
      <td>1.521491e+08</td>
      <td>1.539119e+08</td>
      <td>1.557271e+08</td>
      <td>1.575713e+08</td>
      <td>1.594053e+08</td>
      <td>1.612009e+08</td>
      <td>1.629516e+08</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>19</th>
      <td>Bulgaria</td>
      <td>BGR</td>
      <td>Population, total</td>
      <td>SP.POP.TOTL</td>
      <td>7.867374e+06</td>
      <td>7.943118e+06</td>
      <td>8.012946e+06</td>
      <td>8.078145e+06</td>
      <td>8.144340e+06</td>
      <td>8.204168e+06</td>
      <td>...</td>
      <td>7.444443e+06</td>
      <td>7.395599e+06</td>
      <td>7.348328e+06</td>
      <td>7.305888e+06</td>
      <td>7.265115e+06</td>
      <td>7.223938e+06</td>
      <td>7.177991e+06</td>
      <td>7.127822e+06</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>20</th>
      <td>Bahrain</td>
      <td>BHR</td>
      <td>Population, total</td>
      <td>SP.POP.TOTL</td>
      <td>1.624270e+05</td>
      <td>1.678940e+05</td>
      <td>1.731440e+05</td>
      <td>1.781400e+05</td>
      <td>1.828870e+05</td>
      <td>1.874310e+05</td>
      <td>...</td>
      <td>1.185029e+06</td>
      <td>1.240862e+06</td>
      <td>1.278269e+06</td>
      <td>1.300217e+06</td>
      <td>1.315411e+06</td>
      <td>1.336397e+06</td>
      <td>1.371855e+06</td>
      <td>1.425171e+06</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>21</th>
      <td>Bahamas, The</td>
      <td>BHS</td>
      <td>Population, total</td>
      <td>SP.POP.TOTL</td>
      <td>1.095280e+05</td>
      <td>1.151080e+05</td>
      <td>1.210830e+05</td>
      <td>1.273330e+05</td>
      <td>1.336980e+05</td>
      <td>1.400540e+05</td>
      <td>...</td>
      <td>3.548560e+05</td>
      <td>3.608320e+05</td>
      <td>3.665680e+05</td>
      <td>3.720390e+05</td>
      <td>3.772400e+05</td>
      <td>3.821690e+05</td>
      <td>3.868380e+05</td>
      <td>3.912320e+05</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>22</th>
      <td>Bosnia and Herzegovina</td>
      <td>BIH</td>
      <td>Population, total</td>
      <td>SP.POP.TOTL</td>
      <td>3.225668e+06</td>
      <td>3.288602e+06</td>
      <td>3.353226e+06</td>
      <td>3.417574e+06</td>
      <td>3.478995e+06</td>
      <td>3.535640e+06</td>
      <td>...</td>
      <td>3.746561e+06</td>
      <td>3.722084e+06</td>
      <td>3.688865e+06</td>
      <td>3.648200e+06</td>
      <td>3.604999e+06</td>
      <td>3.566002e+06</td>
      <td>3.535961e+06</td>
      <td>3.516816e+06</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>23</th>
      <td>Belarus</td>
      <td>BLR</td>
      <td>Population, total</td>
      <td>SP.POP.TOTL</td>
      <td>8.198000e+06</td>
      <td>8.271216e+06</td>
      <td>8.351928e+06</td>
      <td>8.437232e+06</td>
      <td>8.524224e+06</td>
      <td>8.610000e+06</td>
      <td>...</td>
      <td>9.506765e+06</td>
      <td>9.490583e+06</td>
      <td>9.473172e+06</td>
      <td>9.464495e+06</td>
      <td>9.465997e+06</td>
      <td>9.474511e+06</td>
      <td>9.489616e+06</td>
      <td>9.501534e+06</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>24</th>
      <td>Belize</td>
      <td>BLZ</td>
      <td>Population, total</td>
      <td>SP.POP.TOTL</td>
      <td>9.206400e+04</td>
      <td>9.470300e+04</td>
      <td>9.738400e+04</td>
      <td>1.001640e+05</td>
      <td>1.030690e+05</td>
      <td>1.061190e+05</td>
      <td>...</td>
      <td>3.139290e+05</td>
      <td>3.216080e+05</td>
      <td>3.291920e+05</td>
      <td>3.367010e+05</td>
      <td>3.441810e+05</td>
      <td>3.516940e+05</td>
      <td>3.592880e+05</td>
      <td>3.669540e+05</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>25</th>
      <td>Bermuda</td>
      <td>BMU</td>
      <td>Population, total</td>
      <td>SP.POP.TOTL</td>
      <td>4.440000e+04</td>
      <td>4.550000e+04</td>
      <td>4.660000e+04</td>
      <td>4.770000e+04</td>
      <td>4.890000e+04</td>
      <td>5.010000e+04</td>
      <td>...</td>
      <td>6.563600e+04</td>
      <td>6.512400e+04</td>
      <td>6.456400e+04</td>
      <td>6.479800e+04</td>
      <td>6.500100e+04</td>
      <td>6.513900e+04</td>
      <td>6.525000e+04</td>
      <td>6.537600e+04</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>26</th>
      <td>Bolivia</td>
      <td>BOL</td>
      <td>Population, total</td>
      <td>SP.POP.TOTL</td>
      <td>3.693449e+06</td>
      <td>3.764813e+06</td>
      <td>3.838097e+06</td>
      <td>3.913395e+06</td>
      <td>3.990857e+06</td>
      <td>4.070590e+06</td>
      <td>...</td>
      <td>9.758748e+06</td>
      <td>9.918242e+06</td>
      <td>1.007834e+07</td>
      <td>1.023900e+07</td>
      <td>1.040026e+07</td>
      <td>1.056216e+07</td>
      <td>1.072470e+07</td>
      <td>1.088788e+07</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>27</th>
      <td>Brazil</td>
      <td>BRA</td>
      <td>Population, total</td>
      <td>SP.POP.TOTL</td>
      <td>7.220755e+07</td>
      <td>7.435176e+07</td>
      <td>7.657325e+07</td>
      <td>7.885402e+07</td>
      <td>8.116865e+07</td>
      <td>8.349802e+07</td>
      <td>...</td>
      <td>1.948960e+08</td>
      <td>1.967963e+08</td>
      <td>1.986867e+08</td>
      <td>2.005610e+08</td>
      <td>2.024086e+08</td>
      <td>2.042131e+08</td>
      <td>2.059621e+08</td>
      <td>2.076529e+08</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>28</th>
      <td>Barbados</td>
      <td>BRB</td>
      <td>Population, total</td>
      <td>SP.POP.TOTL</td>
      <td>2.309390e+05</td>
      <td>2.316780e+05</td>
      <td>2.325860e+05</td>
      <td>2.335870e+05</td>
      <td>2.345470e+05</td>
      <td>2.353740e+05</td>
      <td>...</td>
      <td>2.784700e+05</td>
      <td>2.795690e+05</td>
      <td>2.806010e+05</td>
      <td>2.815850e+05</td>
      <td>2.825090e+05</td>
      <td>2.833850e+05</td>
      <td>2.842170e+05</td>
      <td>2.849960e+05</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>29</th>
      <td>Brunei Darussalam</td>
      <td>BRN</td>
      <td>Population, total</td>
      <td>SP.POP.TOTL</td>
      <td>8.174500e+04</td>
      <td>8.559600e+04</td>
      <td>8.951600e+04</td>
      <td>9.357600e+04</td>
      <td>9.784800e+04</td>
      <td>1.024250e+05</td>
      <td>...</td>
      <td>3.837720e+05</td>
      <td>3.886620e+05</td>
      <td>3.940130e+05</td>
      <td>3.997480e+05</td>
      <td>4.057160e+05</td>
      <td>4.117040e+05</td>
      <td>4.175420e+05</td>
      <td>4.231960e+05</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>234</th>
      <td>Latin America &amp; the Caribbean (IDA &amp; IBRD coun...</td>
      <td>TLA</td>
      <td>Population, total</td>
      <td>SP.POP.TOTL</td>
      <td>2.103576e+08</td>
      <td>2.162859e+08</td>
      <td>2.223965e+08</td>
      <td>2.286630e+08</td>
      <td>2.350485e+08</td>
      <td>2.415251e+08</td>
      <td>...</td>
      <td>5.731253e+08</td>
      <td>5.802468e+08</td>
      <td>5.873151e+08</td>
      <td>5.943307e+08</td>
      <td>6.012772e+08</td>
      <td>6.081360e+08</td>
      <td>6.148920e+08</td>
      <td>6.215349e+08</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>235</th>
      <td>Timor-Leste</td>
      <td>TLS</td>
      <td>Population, total</td>
      <td>SP.POP.TOTL</td>
      <td>4.999500e+05</td>
      <td>5.088450e+05</td>
      <td>5.181070e+05</td>
      <td>5.277490e+05</td>
      <td>5.377860e+05</td>
      <td>5.482180e+05</td>
      <td>...</td>
      <td>1.092021e+06</td>
      <td>1.109591e+06</td>
      <td>1.131523e+06</td>
      <td>1.156760e+06</td>
      <td>1.184366e+06</td>
      <td>1.212814e+06</td>
      <td>1.240977e+06</td>
      <td>1.268671e+06</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>236</th>
      <td>Middle East &amp; North Africa (IDA &amp; IBRD countries)</td>
      <td>TMN</td>
      <td>Population, total</td>
      <td>SP.POP.TOTL</td>
      <td>9.783777e+07</td>
      <td>1.004585e+08</td>
      <td>1.031472e+08</td>
      <td>1.059144e+08</td>
      <td>1.087749e+08</td>
      <td>1.117382e+08</td>
      <td>...</td>
      <td>3.257867e+08</td>
      <td>3.317705e+08</td>
      <td>3.378950e+08</td>
      <td>3.441488e+08</td>
      <td>3.504715e+08</td>
      <td>3.567833e+08</td>
      <td>3.630272e+08</td>
      <td>3.691675e+08</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>237</th>
      <td>Tonga</td>
      <td>TON</td>
      <td>Population, total</td>
      <td>SP.POP.TOTL</td>
      <td>6.160100e+04</td>
      <td>6.374500e+04</td>
      <td>6.625900e+04</td>
      <td>6.900500e+04</td>
      <td>7.175700e+04</td>
      <td>7.436200e+04</td>
      <td>...</td>
      <td>1.036040e+05</td>
      <td>1.041370e+05</td>
      <td>1.045770e+05</td>
      <td>1.049510e+05</td>
      <td>1.053280e+05</td>
      <td>1.057820e+05</td>
      <td>1.063640e+05</td>
      <td>1.071220e+05</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>238</th>
      <td>South Asia (IDA &amp; IBRD)</td>
      <td>TSA</td>
      <td>Population, total</td>
      <td>SP.POP.TOTL</td>
      <td>5.718357e+08</td>
      <td>5.838941e+08</td>
      <td>5.964139e+08</td>
      <td>6.093918e+08</td>
      <td>6.228226e+08</td>
      <td>6.367018e+08</td>
      <td>...</td>
      <td>1.607664e+09</td>
      <td>1.630807e+09</td>
      <td>1.653799e+09</td>
      <td>1.676615e+09</td>
      <td>1.699310e+09</td>
      <td>1.721848e+09</td>
      <td>1.744200e+09</td>
      <td>1.766394e+09</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>239</th>
      <td>Sub-Saharan Africa (IDA &amp; IBRD countries)</td>
      <td>TSS</td>
      <td>Population, total</td>
      <td>SP.POP.TOTL</td>
      <td>2.285860e+08</td>
      <td>2.340086e+08</td>
      <td>2.396471e+08</td>
      <td>2.455033e+08</td>
      <td>2.515764e+08</td>
      <td>2.578686e+08</td>
      <td>...</td>
      <td>8.539537e+08</td>
      <td>8.776284e+08</td>
      <td>9.019899e+08</td>
      <td>9.270399e+08</td>
      <td>9.527341e+08</td>
      <td>9.790179e+08</td>
      <td>1.005850e+09</td>
      <td>1.033213e+09</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>240</th>
      <td>Trinidad and Tobago</td>
      <td>TTO</td>
      <td>Population, total</td>
      <td>SP.POP.TOTL</td>
      <td>8.484790e+05</td>
      <td>8.653600e+05</td>
      <td>8.800230e+05</td>
      <td>8.925690e+05</td>
      <td>9.032750e+05</td>
      <td>9.124170e+05</td>
      <td>...</td>
      <td>1.321618e+06</td>
      <td>1.328100e+06</td>
      <td>1.334788e+06</td>
      <td>1.341588e+06</td>
      <td>1.348248e+06</td>
      <td>1.354493e+06</td>
      <td>1.360092e+06</td>
      <td>1.364962e+06</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>241</th>
      <td>Tunisia</td>
      <td>TUN</td>
      <td>Population, total</td>
      <td>SP.POP.TOTL</td>
      <td>4.176266e+06</td>
      <td>4.235937e+06</td>
      <td>4.303131e+06</td>
      <td>4.377637e+06</td>
      <td>4.458611e+06</td>
      <td>4.545339e+06</td>
      <td>...</td>
      <td>1.052183e+07</td>
      <td>1.063993e+07</td>
      <td>1.076147e+07</td>
      <td>1.088667e+07</td>
      <td>1.101456e+07</td>
      <td>1.114391e+07</td>
      <td>1.127366e+07</td>
      <td>1.140325e+07</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>242</th>
      <td>Turkey</td>
      <td>TUR</td>
      <td>Population, total</td>
      <td>SP.POP.TOTL</td>
      <td>2.747233e+07</td>
      <td>2.814689e+07</td>
      <td>2.883280e+07</td>
      <td>2.953134e+07</td>
      <td>3.024423e+07</td>
      <td>3.097296e+07</td>
      <td>...</td>
      <td>7.133918e+07</td>
      <td>7.232691e+07</td>
      <td>7.340946e+07</td>
      <td>7.456987e+07</td>
      <td>7.578733e+07</td>
      <td>7.703063e+07</td>
      <td>7.827147e+07</td>
      <td>7.951243e+07</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>243</th>
      <td>Tuvalu</td>
      <td>TUV</td>
      <td>Population, total</td>
      <td>SP.POP.TOTL</td>
      <td>6.104000e+03</td>
      <td>6.246000e+03</td>
      <td>6.389000e+03</td>
      <td>6.538000e+03</td>
      <td>6.684000e+03</td>
      <td>6.815000e+03</td>
      <td>...</td>
      <td>1.044100e+04</td>
      <td>1.053100e+04</td>
      <td>1.062800e+04</td>
      <td>1.072500e+04</td>
      <td>1.081900e+04</td>
      <td>1.090800e+04</td>
      <td>1.100100e+04</td>
      <td>1.109700e+04</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>244</th>
      <td>Tanzania</td>
      <td>TZA</td>
      <td>Population, total</td>
      <td>SP.POP.TOTL</td>
      <td>1.007451e+07</td>
      <td>1.037340e+07</td>
      <td>1.068391e+07</td>
      <td>1.100590e+07</td>
      <td>1.133910e+07</td>
      <td>1.168353e+07</td>
      <td>...</td>
      <td>4.466423e+07</td>
      <td>4.609859e+07</td>
      <td>4.757090e+07</td>
      <td>4.908300e+07</td>
      <td>5.063660e+07</td>
      <td>5.223487e+07</td>
      <td>5.387996e+07</td>
      <td>5.557220e+07</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>245</th>
      <td>Uganda</td>
      <td>UGA</td>
      <td>Population, total</td>
      <td>SP.POP.TOTL</td>
      <td>6.788214e+06</td>
      <td>7.006633e+06</td>
      <td>7.240174e+06</td>
      <td>7.487429e+06</td>
      <td>7.746198e+06</td>
      <td>8.014401e+06</td>
      <td>...</td>
      <td>3.277190e+07</td>
      <td>3.391513e+07</td>
      <td>3.509365e+07</td>
      <td>3.630680e+07</td>
      <td>3.755373e+07</td>
      <td>3.883334e+07</td>
      <td>4.014487e+07</td>
      <td>4.148796e+07</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>246</th>
      <td>Ukraine</td>
      <td>UKR</td>
      <td>Population, total</td>
      <td>SP.POP.TOTL</td>
      <td>4.266215e+07</td>
      <td>4.320364e+07</td>
      <td>4.374947e+07</td>
      <td>4.428590e+07</td>
      <td>4.479433e+07</td>
      <td>4.526194e+07</td>
      <td>...</td>
      <td>4.605330e+07</td>
      <td>4.587070e+07</td>
      <td>4.570610e+07</td>
      <td>4.559330e+07</td>
      <td>4.548960e+07</td>
      <td>4.527195e+07</td>
      <td>4.515403e+07</td>
      <td>4.500464e+07</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>247</th>
      <td>Upper middle income</td>
      <td>UMC</td>
      <td>Population, total</td>
      <td>SP.POP.TOTL</td>
      <td>1.169444e+09</td>
      <td>1.174009e+09</td>
      <td>1.191029e+09</td>
      <td>1.219430e+09</td>
      <td>1.247487e+09</td>
      <td>1.276487e+09</td>
      <td>...</td>
      <td>2.447176e+09</td>
      <td>2.465138e+09</td>
      <td>2.483421e+09</td>
      <td>2.502483e+09</td>
      <td>2.521915e+09</td>
      <td>2.541466e+09</td>
      <td>2.560700e+09</td>
      <td>2.580012e+09</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>248</th>
      <td>Uruguay</td>
      <td>URY</td>
      <td>Population, total</td>
      <td>SP.POP.TOTL</td>
      <td>2.538651e+06</td>
      <td>2.571690e+06</td>
      <td>2.603887e+06</td>
      <td>2.635129e+06</td>
      <td>2.665390e+06</td>
      <td>2.694537e+06</td>
      <td>...</td>
      <td>3.362755e+06</td>
      <td>3.374415e+06</td>
      <td>3.385624e+06</td>
      <td>3.396777e+06</td>
      <td>3.408005e+06</td>
      <td>3.419546e+06</td>
      <td>3.431552e+06</td>
      <td>3.444006e+06</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>249</th>
      <td>United States</td>
      <td>USA</td>
      <td>Population, total</td>
      <td>SP.POP.TOTL</td>
      <td>1.806710e+08</td>
      <td>1.836910e+08</td>
      <td>1.865380e+08</td>
      <td>1.892420e+08</td>
      <td>1.918890e+08</td>
      <td>1.943030e+08</td>
      <td>...</td>
      <td>3.067715e+08</td>
      <td>3.093482e+08</td>
      <td>3.116634e+08</td>
      <td>3.139984e+08</td>
      <td>3.162049e+08</td>
      <td>3.185635e+08</td>
      <td>3.208966e+08</td>
      <td>3.231275e+08</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>250</th>
      <td>Uzbekistan</td>
      <td>UZB</td>
      <td>Population, total</td>
      <td>SP.POP.TOTL</td>
      <td>8.549493e+06</td>
      <td>8.837349e+06</td>
      <td>9.138097e+06</td>
      <td>9.454250e+06</td>
      <td>9.788986e+06</td>
      <td>1.014374e+07</td>
      <td>...</td>
      <td>2.776740e+07</td>
      <td>2.856240e+07</td>
      <td>2.933940e+07</td>
      <td>2.977450e+07</td>
      <td>3.024320e+07</td>
      <td>3.075770e+07</td>
      <td>3.129890e+07</td>
      <td>3.184790e+07</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>251</th>
      <td>St. Vincent and the Grenadines</td>
      <td>VCT</td>
      <td>Population, total</td>
      <td>SP.POP.TOTL</td>
      <td>8.094900e+04</td>
      <td>8.214200e+04</td>
      <td>8.320600e+04</td>
      <td>8.416700e+04</td>
      <td>8.506900e+04</td>
      <td>8.597000e+04</td>
      <td>...</td>
      <td>1.092530e+05</td>
      <td>1.093150e+05</td>
      <td>1.093410e+05</td>
      <td>1.093280e+05</td>
      <td>1.093200e+05</td>
      <td>1.093570e+05</td>
      <td>1.094550e+05</td>
      <td>1.096430e+05</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>252</th>
      <td>Venezuela, RB</td>
      <td>VEN</td>
      <td>Population, total</td>
      <td>SP.POP.TOTL</td>
      <td>8.146847e+06</td>
      <td>8.461685e+06</td>
      <td>8.790589e+06</td>
      <td>9.130349e+06</td>
      <td>9.476252e+06</td>
      <td>9.824692e+06</td>
      <td>...</td>
      <td>2.858732e+07</td>
      <td>2.902803e+07</td>
      <td>2.946329e+07</td>
      <td>2.989308e+07</td>
      <td>3.031785e+07</td>
      <td>3.073838e+07</td>
      <td>3.115513e+07</td>
      <td>3.156818e+07</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>253</th>
      <td>British Virgin Islands</td>
      <td>VGB</td>
      <td>Population, total</td>
      <td>SP.POP.TOTL</td>
      <td>8.033000e+03</td>
      <td>8.155000e+03</td>
      <td>8.298000e+03</td>
      <td>8.452000e+03</td>
      <td>8.627000e+03</td>
      <td>8.814000e+03</td>
      <td>...</td>
      <td>2.644700e+04</td>
      <td>2.722400e+04</td>
      <td>2.790100e+04</td>
      <td>2.850900e+04</td>
      <td>2.905600e+04</td>
      <td>2.958800e+04</td>
      <td>3.011300e+04</td>
      <td>3.066100e+04</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>254</th>
      <td>Virgin Islands (U.S.)</td>
      <td>VIR</td>
      <td>Population, total</td>
      <td>SP.POP.TOTL</td>
      <td>3.250000e+04</td>
      <td>3.430000e+04</td>
      <td>3.500000e+04</td>
      <td>3.980000e+04</td>
      <td>4.080000e+04</td>
      <td>4.350000e+04</td>
      <td>...</td>
      <td>1.084050e+05</td>
      <td>1.083580e+05</td>
      <td>1.082920e+05</td>
      <td>1.081910e+05</td>
      <td>1.080440e+05</td>
      <td>1.078840e+05</td>
      <td>1.077100e+05</td>
      <td>1.075100e+05</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>255</th>
      <td>Vietnam</td>
      <td>VNM</td>
      <td>Population, total</td>
      <td>SP.POP.TOTL</td>
      <td>3.267063e+07</td>
      <td>3.366677e+07</td>
      <td>3.468416e+07</td>
      <td>3.572209e+07</td>
      <td>3.678098e+07</td>
      <td>3.786001e+07</td>
      <td>...</td>
      <td>8.756541e+07</td>
      <td>8.847251e+07</td>
      <td>8.943664e+07</td>
      <td>9.045188e+07</td>
      <td>9.149772e+07</td>
      <td>9.254492e+07</td>
      <td>9.357157e+07</td>
      <td>9.456907e+07</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>256</th>
      <td>Vanuatu</td>
      <td>VUT</td>
      <td>Population, total</td>
      <td>SP.POP.TOTL</td>
      <td>6.369900e+04</td>
      <td>6.571300e+04</td>
      <td>6.780800e+04</td>
      <td>6.996400e+04</td>
      <td>7.213100e+04</td>
      <td>7.428900e+04</td>
      <td>...</td>
      <td>2.307850e+05</td>
      <td>2.362950e+05</td>
      <td>2.418710e+05</td>
      <td>2.474850e+05</td>
      <td>2.531420e+05</td>
      <td>2.588500e+05</td>
      <td>2.646030e+05</td>
      <td>2.704020e+05</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>257</th>
      <td>World</td>
      <td>WLD</td>
      <td>Population, total</td>
      <td>SP.POP.TOTL</td>
      <td>3.032160e+09</td>
      <td>3.073369e+09</td>
      <td>3.126510e+09</td>
      <td>3.191786e+09</td>
      <td>3.257460e+09</td>
      <td>3.324545e+09</td>
      <td>...</td>
      <td>6.849573e+09</td>
      <td>6.932881e+09</td>
      <td>7.014999e+09</td>
      <td>7.099549e+09</td>
      <td>7.185078e+09</td>
      <td>7.271228e+09</td>
      <td>7.357370e+09</td>
      <td>7.444027e+09</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>258</th>
      <td>Samoa</td>
      <td>WSM</td>
      <td>Population, total</td>
      <td>SP.POP.TOTL</td>
      <td>1.086460e+05</td>
      <td>1.121190e+05</td>
      <td>1.157880e+05</td>
      <td>1.195610e+05</td>
      <td>1.233540e+05</td>
      <td>1.270680e+05</td>
      <td>...</td>
      <td>1.848260e+05</td>
      <td>1.862050e+05</td>
      <td>1.876650e+05</td>
      <td>1.891940e+05</td>
      <td>1.907570e+05</td>
      <td>1.922900e+05</td>
      <td>1.937590e+05</td>
      <td>1.951250e+05</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>259</th>
      <td>Kosovo</td>
      <td>XKX</td>
      <td>Population, total</td>
      <td>SP.POP.TOTL</td>
      <td>9.470000e+05</td>
      <td>9.660000e+05</td>
      <td>9.940000e+05</td>
      <td>1.022000e+06</td>
      <td>1.050000e+06</td>
      <td>1.078000e+06</td>
      <td>...</td>
      <td>1.761474e+06</td>
      <td>1.775680e+06</td>
      <td>1.791000e+06</td>
      <td>1.805200e+06</td>
      <td>1.824100e+06</td>
      <td>1.821800e+06</td>
      <td>1.801800e+06</td>
      <td>1.816200e+06</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>260</th>
      <td>Yemen, Rep.</td>
      <td>YEM</td>
      <td>Population, total</td>
      <td>SP.POP.TOTL</td>
      <td>5.172135e+06</td>
      <td>5.260501e+06</td>
      <td>5.351799e+06</td>
      <td>5.446063e+06</td>
      <td>5.543339e+06</td>
      <td>5.643643e+06</td>
      <td>...</td>
      <td>2.297493e+07</td>
      <td>2.360678e+07</td>
      <td>2.425221e+07</td>
      <td>2.490997e+07</td>
      <td>2.557632e+07</td>
      <td>2.624633e+07</td>
      <td>2.691621e+07</td>
      <td>2.758421e+07</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>261</th>
      <td>South Africa</td>
      <td>ZAF</td>
      <td>Population, total</td>
      <td>SP.POP.TOTL</td>
      <td>1.745686e+07</td>
      <td>1.792067e+07</td>
      <td>1.840161e+07</td>
      <td>1.889928e+07</td>
      <td>1.941298e+07</td>
      <td>1.994230e+07</td>
      <td>...</td>
      <td>5.097082e+07</td>
      <td>5.158466e+07</td>
      <td>5.226352e+07</td>
      <td>5.299821e+07</td>
      <td>5.376740e+07</td>
      <td>5.453957e+07</td>
      <td>5.529122e+07</td>
      <td>5.601547e+07</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>262</th>
      <td>Zambia</td>
      <td>ZMB</td>
      <td>Population, total</td>
      <td>SP.POP.TOTL</td>
      <td>3.044846e+06</td>
      <td>3.140264e+06</td>
      <td>3.240587e+06</td>
      <td>3.345145e+06</td>
      <td>3.452942e+06</td>
      <td>3.563407e+06</td>
      <td>...</td>
      <td>1.345642e+07</td>
      <td>1.385003e+07</td>
      <td>1.426476e+07</td>
      <td>1.469994e+07</td>
      <td>1.515321e+07</td>
      <td>1.562097e+07</td>
      <td>1.610059e+07</td>
      <td>1.659139e+07</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>263</th>
      <td>Zimbabwe</td>
      <td>ZWE</td>
      <td>Population, total</td>
      <td>SP.POP.TOTL</td>
      <td>3.747369e+06</td>
      <td>3.870756e+06</td>
      <td>3.999419e+06</td>
      <td>4.132756e+06</td>
      <td>4.269863e+06</td>
      <td>4.410212e+06</td>
      <td>...</td>
      <td>1.381060e+07</td>
      <td>1.408632e+07</td>
      <td>1.438665e+07</td>
      <td>1.471083e+07</td>
      <td>1.505451e+07</td>
      <td>1.541168e+07</td>
      <td>1.577745e+07</td>
      <td>1.615036e+07</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
<p>264 rows × 63 columns</p>
</div>




```python
population = population[["Country Name", "2015", "2016"]]
population.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Country Name</th>
      <th>2015</th>
      <th>2016</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Aruba</td>
      <td>104341.0</td>
      <td>104822.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Afghanistan</td>
      <td>33736494.0</td>
      <td>34656032.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Angola</td>
      <td>27859305.0</td>
      <td>28813463.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Albania</td>
      <td>2880703.0</td>
      <td>2876101.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Andorra</td>
      <td>78014.0</td>
      <td>77281.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
Final_happiness = pd.merge(Final_happiness, population, on="Country Name", how = "inner")
Final_happiness.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Country Name</th>
      <th>Happiness Rank 2015</th>
      <th>Happiness Rank 2016</th>
      <th>Happiness Score 2015</th>
      <th>Happiness Score 2016</th>
      <th>2015_x</th>
      <th>2016_x</th>
      <th>2015_y</th>
      <th>2016_y</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Switzerland</td>
      <td>1</td>
      <td>2</td>
      <td>7.587</td>
      <td>7.509</td>
      <td>6.790000e+11</td>
      <td>6.690000e+11</td>
      <td>8282396.0</td>
      <td>8372413.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Iceland</td>
      <td>2</td>
      <td>3</td>
      <td>7.561</td>
      <td>7.501</td>
      <td>1.694225e+10</td>
      <td>2.030410e+10</td>
      <td>330815.0</td>
      <td>335439.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Denmark</td>
      <td>3</td>
      <td>1</td>
      <td>7.527</td>
      <td>7.526</td>
      <td>3.010000e+11</td>
      <td>3.070000e+11</td>
      <td>5683483.0</td>
      <td>5728010.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Norway</td>
      <td>4</td>
      <td>4</td>
      <td>7.522</td>
      <td>7.498</td>
      <td>3.870000e+11</td>
      <td>3.710000e+11</td>
      <td>5190239.0</td>
      <td>5236151.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Canada</td>
      <td>5</td>
      <td>6</td>
      <td>7.427</td>
      <td>7.404</td>
      <td>1.560000e+12</td>
      <td>1.540000e+12</td>
      <td>35832513.0</td>
      <td>36264604.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
Final_happiness = Final_happiness.rename(columns = {"2015_x":"GDP 2015", "2016_x": "GDP 2016", "2015_y":"Population 2015", "2016_y":"Population 2016"})
Final_happiness.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Country Name</th>
      <th>Happiness Rank 2015</th>
      <th>Happiness Rank 2016</th>
      <th>Happiness Score 2015</th>
      <th>Happiness Score 2016</th>
      <th>GDP 2015</th>
      <th>GDP 2016</th>
      <th>Population 2015</th>
      <th>Population 2016</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Switzerland</td>
      <td>1</td>
      <td>2</td>
      <td>7.587</td>
      <td>7.509</td>
      <td>6.790000e+11</td>
      <td>6.690000e+11</td>
      <td>8282396.0</td>
      <td>8372413.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Iceland</td>
      <td>2</td>
      <td>3</td>
      <td>7.561</td>
      <td>7.501</td>
      <td>1.694225e+10</td>
      <td>2.030410e+10</td>
      <td>330815.0</td>
      <td>335439.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Denmark</td>
      <td>3</td>
      <td>1</td>
      <td>7.527</td>
      <td>7.526</td>
      <td>3.010000e+11</td>
      <td>3.070000e+11</td>
      <td>5683483.0</td>
      <td>5728010.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Norway</td>
      <td>4</td>
      <td>4</td>
      <td>7.522</td>
      <td>7.498</td>
      <td>3.870000e+11</td>
      <td>3.710000e+11</td>
      <td>5190239.0</td>
      <td>5236151.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Canada</td>
      <td>5</td>
      <td>6</td>
      <td>7.427</td>
      <td>7.404</td>
      <td>1.560000e+12</td>
      <td>1.540000e+12</td>
      <td>35832513.0</td>
      <td>36264604.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
Final_happiness['GDP Per capita 2015'] = Final_happiness['GDP 2015']/Final_happiness['Population 2015']
Final_happiness['GDP per capita 2016'] = Final_happiness['GDP 2016']/Final_happiness['Population 2016']
Final_happiness
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Country Name</th>
      <th>Happiness Rank 2015</th>
      <th>Happiness Rank 2016</th>
      <th>Happiness Score 2015</th>
      <th>Happiness Score 2016</th>
      <th>GDP 2015</th>
      <th>GDP 2016</th>
      <th>Population 2015</th>
      <th>Population 2016</th>
      <th>GDP Per capita 2015</th>
      <th>GDP per capita 2016</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Switzerland</td>
      <td>1</td>
      <td>2</td>
      <td>7.587</td>
      <td>7.509</td>
      <td>6.790000e+11</td>
      <td>6.690000e+11</td>
      <td>8.282396e+06</td>
      <td>8.372413e+06</td>
      <td>81981.107882</td>
      <td>79905.279398</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Iceland</td>
      <td>2</td>
      <td>3</td>
      <td>7.561</td>
      <td>7.501</td>
      <td>1.694225e+10</td>
      <td>2.030410e+10</td>
      <td>3.308150e+05</td>
      <td>3.354390e+05</td>
      <td>51213.661333</td>
      <td>60529.926756</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Denmark</td>
      <td>3</td>
      <td>1</td>
      <td>7.527</td>
      <td>7.526</td>
      <td>3.010000e+11</td>
      <td>3.070000e+11</td>
      <td>5.683483e+06</td>
      <td>5.728010e+06</td>
      <td>52960.482155</td>
      <td>53596.275146</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Norway</td>
      <td>4</td>
      <td>4</td>
      <td>7.522</td>
      <td>7.498</td>
      <td>3.870000e+11</td>
      <td>3.710000e+11</td>
      <td>5.190239e+06</td>
      <td>5.236151e+06</td>
      <td>74563.040353</td>
      <td>70853.571641</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Canada</td>
      <td>5</td>
      <td>6</td>
      <td>7.427</td>
      <td>7.404</td>
      <td>1.560000e+12</td>
      <td>1.540000e+12</td>
      <td>3.583251e+07</td>
      <td>3.626460e+07</td>
      <td>43535.880389</td>
      <td>42465.650528</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Netherlands</td>
      <td>7</td>
      <td>7</td>
      <td>7.378</td>
      <td>7.339</td>
      <td>7.580000e+11</td>
      <td>7.770000e+11</td>
      <td>1.693992e+07</td>
      <td>1.703031e+07</td>
      <td>44746.366321</td>
      <td>45624.525772</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Sweden</td>
      <td>8</td>
      <td>10</td>
      <td>7.364</td>
      <td>7.291</td>
      <td>4.980000e+11</td>
      <td>5.140000e+11</td>
      <td>9.799186e+06</td>
      <td>9.923085e+06</td>
      <td>50820.547748</td>
      <td>51798.407451</td>
    </tr>
    <tr>
      <th>7</th>
      <td>New Zealand</td>
      <td>9</td>
      <td>8</td>
      <td>7.286</td>
      <td>7.334</td>
      <td>1.760000e+11</td>
      <td>1.850000e+11</td>
      <td>4.595700e+06</td>
      <td>4.693200e+06</td>
      <td>38296.668625</td>
      <td>39418.733487</td>
    </tr>
    <tr>
      <th>8</th>
      <td>Australia</td>
      <td>10</td>
      <td>9</td>
      <td>7.284</td>
      <td>7.313</td>
      <td>1.350000e+12</td>
      <td>1.200000e+12</td>
      <td>2.385078e+07</td>
      <td>2.421081e+07</td>
      <td>56601.912960</td>
      <td>49564.638670</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Israel</td>
      <td>11</td>
      <td>11</td>
      <td>7.278</td>
      <td>7.267</td>
      <td>2.990000e+11</td>
      <td>3.180000e+11</td>
      <td>8.380100e+06</td>
      <td>8.546000e+06</td>
      <td>35679.765158</td>
      <td>37210.390826</td>
    </tr>
    <tr>
      <th>10</th>
      <td>Costa Rica</td>
      <td>12</td>
      <td>14</td>
      <td>7.226</td>
      <td>7.087</td>
      <td>5.484010e+10</td>
      <td>5.743551e+10</td>
      <td>4.807852e+06</td>
      <td>4.857274e+06</td>
      <td>11406.362727</td>
      <td>11824.638102</td>
    </tr>
    <tr>
      <th>11</th>
      <td>Austria</td>
      <td>13</td>
      <td>12</td>
      <td>7.200</td>
      <td>7.119</td>
      <td>3.820000e+11</td>
      <td>3.910000e+11</td>
      <td>8.633169e+06</td>
      <td>8.731471e+06</td>
      <td>44247.946496</td>
      <td>44780.541561</td>
    </tr>
    <tr>
      <th>12</th>
      <td>Mexico</td>
      <td>14</td>
      <td>21</td>
      <td>7.187</td>
      <td>6.778</td>
      <td>1.150000e+12</td>
      <td>1.050000e+12</td>
      <td>1.258909e+08</td>
      <td>1.275404e+08</td>
      <td>9134.890229</td>
      <td>8232.684002</td>
    </tr>
    <tr>
      <th>13</th>
      <td>United States</td>
      <td>15</td>
      <td>13</td>
      <td>7.119</td>
      <td>7.104</td>
      <td>1.810000e+13</td>
      <td>1.860000e+13</td>
      <td>3.208966e+08</td>
      <td>3.231275e+08</td>
      <td>56404.458585</td>
      <td>57562.414996</td>
    </tr>
    <tr>
      <th>14</th>
      <td>Brazil</td>
      <td>16</td>
      <td>17</td>
      <td>6.983</td>
      <td>6.952</td>
      <td>1.800000e+12</td>
      <td>1.800000e+12</td>
      <td>2.059621e+08</td>
      <td>2.076529e+08</td>
      <td>8739.471631</td>
      <td>8668.312860</td>
    </tr>
    <tr>
      <th>15</th>
      <td>Luxembourg</td>
      <td>17</td>
      <td>20</td>
      <td>6.946</td>
      <td>6.871</td>
      <td>5.778450e+10</td>
      <td>5.863132e+10</td>
      <td>5.696040e+05</td>
      <td>5.820140e+05</td>
      <td>101446.786302</td>
      <td>100738.684222</td>
    </tr>
    <tr>
      <th>16</th>
      <td>Ireland</td>
      <td>18</td>
      <td>19</td>
      <td>6.940</td>
      <td>6.907</td>
      <td>2.910000e+11</td>
      <td>3.050000e+11</td>
      <td>4.646554e+06</td>
      <td>4.749777e+06</td>
      <td>62627.056524</td>
      <td>64213.540973</td>
    </tr>
    <tr>
      <th>17</th>
      <td>Belgium</td>
      <td>19</td>
      <td>18</td>
      <td>6.937</td>
      <td>6.929</td>
      <td>4.550000e+11</td>
      <td>4.680000e+11</td>
      <td>1.127420e+07</td>
      <td>1.133848e+07</td>
      <td>40357.645015</td>
      <td>41275.388333</td>
    </tr>
    <tr>
      <th>18</th>
      <td>United Kingdom</td>
      <td>21</td>
      <td>23</td>
      <td>6.867</td>
      <td>6.725</td>
      <td>2.890000e+12</td>
      <td>2.650000e+12</td>
      <td>6.512886e+07</td>
      <td>6.559556e+07</td>
      <td>44373.568885</td>
      <td>40399.072712</td>
    </tr>
    <tr>
      <th>19</th>
      <td>Singapore</td>
      <td>24</td>
      <td>22</td>
      <td>6.798</td>
      <td>6.739</td>
      <td>2.970000e+11</td>
      <td>2.970000e+11</td>
      <td>5.535002e+06</td>
      <td>5.607283e+06</td>
      <td>53658.517197</td>
      <td>52966.829033</td>
    </tr>
    <tr>
      <th>20</th>
      <td>Panama</td>
      <td>25</td>
      <td>25</td>
      <td>6.786</td>
      <td>6.701</td>
      <td>5.213229e+10</td>
      <td>5.518770e+10</td>
      <td>3.969249e+06</td>
      <td>4.034119e+06</td>
      <td>13134.043669</td>
      <td>13680.236007</td>
    </tr>
    <tr>
      <th>21</th>
      <td>Germany</td>
      <td>26</td>
      <td>16</td>
      <td>6.750</td>
      <td>6.994</td>
      <td>3.380000e+12</td>
      <td>3.480000e+12</td>
      <td>8.168661e+07</td>
      <td>8.248784e+07</td>
      <td>41377.650004</td>
      <td>42188.035420</td>
    </tr>
    <tr>
      <th>22</th>
      <td>Chile</td>
      <td>27</td>
      <td>24</td>
      <td>6.670</td>
      <td>6.705</td>
      <td>2.430000e+11</td>
      <td>2.470000e+11</td>
      <td>1.776268e+07</td>
      <td>1.790975e+07</td>
      <td>13680.367282</td>
      <td>13791.367542</td>
    </tr>
    <tr>
      <th>23</th>
      <td>Qatar</td>
      <td>28</td>
      <td>36</td>
      <td>6.611</td>
      <td>6.375</td>
      <td>1.650000e+11</td>
      <td>1.520000e+11</td>
      <td>2.481539e+06</td>
      <td>2.569804e+06</td>
      <td>66490.996112</td>
      <td>59148.479806</td>
    </tr>
    <tr>
      <th>24</th>
      <td>France</td>
      <td>29</td>
      <td>32</td>
      <td>6.575</td>
      <td>6.478</td>
      <td>2.430000e+12</td>
      <td>2.470000e+12</td>
      <td>6.662407e+07</td>
      <td>6.689220e+07</td>
      <td>36473.305713</td>
      <td>36925.079686</td>
    </tr>
    <tr>
      <th>25</th>
      <td>Czech Republic</td>
      <td>31</td>
      <td>27</td>
      <td>6.505</td>
      <td>6.596</td>
      <td>1.870000e+11</td>
      <td>1.950000e+11</td>
      <td>1.054606e+07</td>
      <td>1.056633e+07</td>
      <td>17731.742256</td>
      <td>18454.843175</td>
    </tr>
    <tr>
      <th>26</th>
      <td>Uruguay</td>
      <td>32</td>
      <td>29</td>
      <td>6.485</td>
      <td>6.545</td>
      <td>5.327430e+10</td>
      <td>5.241972e+10</td>
      <td>3.431552e+06</td>
      <td>3.444006e+06</td>
      <td>15524.842466</td>
      <td>15220.566025</td>
    </tr>
    <tr>
      <th>27</th>
      <td>Colombia</td>
      <td>33</td>
      <td>31</td>
      <td>6.477</td>
      <td>6.481</td>
      <td>2.920000e+11</td>
      <td>2.820000e+11</td>
      <td>4.822870e+07</td>
      <td>4.865342e+07</td>
      <td>6054.486606</td>
      <td>5796.098317</td>
    </tr>
    <tr>
      <th>28</th>
      <td>Thailand</td>
      <td>34</td>
      <td>33</td>
      <td>6.455</td>
      <td>6.474</td>
      <td>3.990000e+11</td>
      <td>4.070000e+11</td>
      <td>6.865760e+07</td>
      <td>6.886351e+07</td>
      <td>5811.446948</td>
      <td>5910.241525</td>
    </tr>
    <tr>
      <th>29</th>
      <td>Saudi Arabia</td>
      <td>35</td>
      <td>34</td>
      <td>6.411</td>
      <td>6.379</td>
      <td>6.520000e+11</td>
      <td>6.460000e+11</td>
      <td>3.155714e+07</td>
      <td>3.227569e+07</td>
      <td>20660.931800</td>
      <td>20015.065830</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>57</th>
      <td>Latvia</td>
      <td>89</td>
      <td>68</td>
      <td>5.098</td>
      <td>5.560</td>
      <td>2.697286e+10</td>
      <td>2.757270e+10</td>
      <td>1.977527e+06</td>
      <td>1.959537e+06</td>
      <td>13639.694120</td>
      <td>14071.027228</td>
    </tr>
    <tr>
      <th>58</th>
      <td>Philippines</td>
      <td>90</td>
      <td>82</td>
      <td>5.073</td>
      <td>5.279</td>
      <td>2.930000e+11</td>
      <td>3.050000e+11</td>
      <td>1.017164e+08</td>
      <td>1.033202e+08</td>
      <td>2880.559262</td>
      <td>2951.987463</td>
    </tr>
    <tr>
      <th>59</th>
      <td>Morocco</td>
      <td>92</td>
      <td>90</td>
      <td>5.013</td>
      <td>5.151</td>
      <td>1.010000e+11</td>
      <td>1.040000e+11</td>
      <td>3.480332e+07</td>
      <td>3.527679e+07</td>
      <td>2902.021824</td>
      <td>2948.114378</td>
    </tr>
    <tr>
      <th>60</th>
      <td>Bosnia and Herzegovina</td>
      <td>96</td>
      <td>87</td>
      <td>4.949</td>
      <td>5.163</td>
      <td>1.620970e+10</td>
      <td>1.691028e+10</td>
      <td>3.535961e+06</td>
      <td>3.516816e+06</td>
      <td>4584.242548</td>
      <td>4808.405425</td>
    </tr>
    <tr>
      <th>61</th>
      <td>Dominican Republic</td>
      <td>98</td>
      <td>89</td>
      <td>4.885</td>
      <td>5.155</td>
      <td>6.810262e+10</td>
      <td>7.158355e+10</td>
      <td>1.052839e+07</td>
      <td>1.064879e+07</td>
      <td>6468.471648</td>
      <td>6722.223536</td>
    </tr>
    <tr>
      <th>62</th>
      <td>Mongolia</td>
      <td>100</td>
      <td>101</td>
      <td>4.874</td>
      <td>4.907</td>
      <td>1.174962e+10</td>
      <td>1.118346e+10</td>
      <td>2.976877e+06</td>
      <td>3.027398e+06</td>
      <td>3946.962075</td>
      <td>3694.082552</td>
    </tr>
    <tr>
      <th>63</th>
      <td>Greece</td>
      <td>102</td>
      <td>99</td>
      <td>4.857</td>
      <td>5.033</td>
      <td>1.960000e+11</td>
      <td>1.930000e+11</td>
      <td>1.082088e+07</td>
      <td>1.077052e+07</td>
      <td>18113.124410</td>
      <td>17919.281713</td>
    </tr>
    <tr>
      <th>64</th>
      <td>Hungary</td>
      <td>104</td>
      <td>91</td>
      <td>4.800</td>
      <td>5.145</td>
      <td>1.230000e+11</td>
      <td>1.260000e+11</td>
      <td>9.843028e+06</td>
      <td>9.814023e+06</td>
      <td>12496.154639</td>
      <td>12838.771623</td>
    </tr>
    <tr>
      <th>65</th>
      <td>Honduras</td>
      <td>105</td>
      <td>104</td>
      <td>4.788</td>
      <td>4.871</td>
      <td>2.084428e+10</td>
      <td>2.151694e+10</td>
      <td>8.960829e+06</td>
      <td>9.112867e+06</td>
      <td>2326.155856</td>
      <td>2361.160205</td>
    </tr>
    <tr>
      <th>66</th>
      <td>Tunisia</td>
      <td>107</td>
      <td>98</td>
      <td>4.739</td>
      <td>5.045</td>
      <td>4.315671e+10</td>
      <td>4.206255e+10</td>
      <td>1.127366e+07</td>
      <td>1.140325e+07</td>
      <td>3828.100633</td>
      <td>3688.646375</td>
    </tr>
    <tr>
      <th>67</th>
      <td>Ukraine</td>
      <td>111</td>
      <td>123</td>
      <td>4.681</td>
      <td>4.324</td>
      <td>9.103096e+10</td>
      <td>9.327048e+10</td>
      <td>4.515403e+07</td>
      <td>4.500464e+07</td>
      <td>2016.009678</td>
      <td>2072.463395</td>
    </tr>
    <tr>
      <th>68</th>
      <td>South Africa</td>
      <td>113</td>
      <td>116</td>
      <td>4.642</td>
      <td>4.459</td>
      <td>3.180000e+11</td>
      <td>2.950000e+11</td>
      <td>5.529122e+07</td>
      <td>5.601547e+07</td>
      <td>5751.364706</td>
      <td>5266.402017</td>
    </tr>
    <tr>
      <th>69</th>
      <td>Ghana</td>
      <td>114</td>
      <td>124</td>
      <td>4.633</td>
      <td>4.276</td>
      <td>3.754336e+10</td>
      <td>4.268978e+10</td>
      <td>2.758282e+07</td>
      <td>2.820673e+07</td>
      <td>1361.113905</td>
      <td>1513.461034</td>
    </tr>
    <tr>
      <th>70</th>
      <td>Zimbabwe</td>
      <td>115</td>
      <td>131</td>
      <td>4.610</td>
      <td>4.193</td>
      <td>1.630467e+10</td>
      <td>1.661996e+10</td>
      <td>1.577745e+07</td>
      <td>1.615036e+07</td>
      <td>1033.415842</td>
      <td>1029.076649</td>
    </tr>
    <tr>
      <th>71</th>
      <td>Liberia</td>
      <td>116</td>
      <td>150</td>
      <td>4.571</td>
      <td>3.622</td>
      <td>2.034000e+09</td>
      <td>2.101000e+09</td>
      <td>4.499621e+06</td>
      <td>4.613823e+06</td>
      <td>452.038072</td>
      <td>455.370741</td>
    </tr>
    <tr>
      <th>72</th>
      <td>India</td>
      <td>117</td>
      <td>118</td>
      <td>4.565</td>
      <td>4.404</td>
      <td>2.090000e+12</td>
      <td>2.260000e+12</td>
      <td>1.309054e+09</td>
      <td>1.324171e+09</td>
      <td>1596.572817</td>
      <td>1706.727753</td>
    </tr>
    <tr>
      <th>73</th>
      <td>Nepal</td>
      <td>121</td>
      <td>107</td>
      <td>4.514</td>
      <td>4.793</td>
      <td>2.141084e+10</td>
      <td>2.113198e+10</td>
      <td>2.865628e+07</td>
      <td>2.898277e+07</td>
      <td>747.160462</td>
      <td>729.122251</td>
    </tr>
    <tr>
      <th>74</th>
      <td>Ethiopia</td>
      <td>122</td>
      <td>115</td>
      <td>4.512</td>
      <td>4.508</td>
      <td>6.446455e+10</td>
      <td>7.237422e+10</td>
      <td>9.987303e+07</td>
      <td>1.024032e+08</td>
      <td>645.465007</td>
      <td>706.757475</td>
    </tr>
    <tr>
      <th>75</th>
      <td>Sierra Leone</td>
      <td>123</td>
      <td>111</td>
      <td>4.507</td>
      <td>4.635</td>
      <td>4.251870e+09</td>
      <td>3.736589e+09</td>
      <td>7.237025e+06</td>
      <td>7.396190e+06</td>
      <td>587.516261</td>
      <td>505.204511</td>
    </tr>
    <tr>
      <th>76</th>
      <td>Mauritania</td>
      <td>124</td>
      <td>130</td>
      <td>4.436</td>
      <td>4.201</td>
      <td>4.844223e+09</td>
      <td>4.739299e+09</td>
      <td>4.182341e+06</td>
      <td>4.301018e+06</td>
      <td>1158.256371</td>
      <td>1101.901627</td>
    </tr>
    <tr>
      <th>77</th>
      <td>Kenya</td>
      <td>125</td>
      <td>122</td>
      <td>4.419</td>
      <td>4.356</td>
      <td>6.376754e+10</td>
      <td>7.052901e+10</td>
      <td>4.723626e+07</td>
      <td>4.846157e+07</td>
      <td>1349.970144</td>
      <td>1455.359765</td>
    </tr>
    <tr>
      <th>78</th>
      <td>Georgia</td>
      <td>130</td>
      <td>126</td>
      <td>4.297</td>
      <td>4.252</td>
      <td>1.399355e+10</td>
      <td>1.437802e+10</td>
      <td>3.717100e+06</td>
      <td>3.719300e+06</td>
      <td>3764.640911</td>
      <td>3865.785693</td>
    </tr>
    <tr>
      <th>79</th>
      <td>Malawi</td>
      <td>131</td>
      <td>132</td>
      <td>4.292</td>
      <td>4.156</td>
      <td>6.373201e+09</td>
      <td>5.433039e+09</td>
      <td>1.757361e+07</td>
      <td>1.809158e+07</td>
      <td>362.657544</td>
      <td>300.307665</td>
    </tr>
    <tr>
      <th>80</th>
      <td>Sri Lanka</td>
      <td>132</td>
      <td>117</td>
      <td>4.271</td>
      <td>4.415</td>
      <td>8.061199e+10</td>
      <td>8.132188e+10</td>
      <td>2.096600e+07</td>
      <td>2.120300e+07</td>
      <td>3844.891230</td>
      <td>3835.394817</td>
    </tr>
    <tr>
      <th>81</th>
      <td>Bulgaria</td>
      <td>134</td>
      <td>129</td>
      <td>4.218</td>
      <td>4.217</td>
      <td>5.019912e+10</td>
      <td>5.323788e+10</td>
      <td>7.177991e+06</td>
      <td>7.127822e+06</td>
      <td>6993.477360</td>
      <td>7469.025247</td>
    </tr>
    <tr>
      <th>82</th>
      <td>Senegal</td>
      <td>142</td>
      <td>128</td>
      <td>3.904</td>
      <td>4.219</td>
      <td>1.364067e+10</td>
      <td>1.468370e+10</td>
      <td>1.497699e+07</td>
      <td>1.541161e+07</td>
      <td>910.774777</td>
      <td>952.768323</td>
    </tr>
    <tr>
      <th>83</th>
      <td>Gabon</td>
      <td>143</td>
      <td>134</td>
      <td>3.896</td>
      <td>4.121</td>
      <td>1.426203e+10</td>
      <td>1.421356e+10</td>
      <td>1.930175e+06</td>
      <td>1.979786e+06</td>
      <td>7388.984144</td>
      <td>7179.340661</td>
    </tr>
    <tr>
      <th>84</th>
      <td>Tanzania</td>
      <td>146</td>
      <td>149</td>
      <td>3.781</td>
      <td>3.666</td>
      <td>4.562832e+10</td>
      <td>4.734007e+10</td>
      <td>5.387996e+07</td>
      <td>5.557220e+07</td>
      <td>846.851467</td>
      <td>851.866046</td>
    </tr>
    <tr>
      <th>85</th>
      <td>Rwanda</td>
      <td>154</td>
      <td>152</td>
      <td>3.465</td>
      <td>3.515</td>
      <td>8.261034e+09</td>
      <td>8.376049e+09</td>
      <td>1.162955e+07</td>
      <td>1.191751e+07</td>
      <td>710.348391</td>
      <td>702.835602</td>
    </tr>
    <tr>
      <th>86</th>
      <td>Benin</td>
      <td>155</td>
      <td>153</td>
      <td>3.340</td>
      <td>3.484</td>
      <td>8.290987e+09</td>
      <td>8.583031e+09</td>
      <td>1.057595e+07</td>
      <td>1.087230e+07</td>
      <td>783.947091</td>
      <td>789.440411</td>
    </tr>
  </tbody>
</table>
<p>87 rows × 11 columns</p>
</div>




```python
file4 = "final_cpi_data.csv"
cpi = pd.read_csv(file4)
cpi.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Unnamed: 0</th>
      <th>Country Name</th>
      <th>Indicator Name</th>
      <th>Attribute</th>
      <th>2014</th>
      <th>2015</th>
      <th>2016</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>28</td>
      <td>Brazil</td>
      <td>Consumer Price Index, All items</td>
      <td>Value</td>
      <td>3953.157500</td>
      <td>4310.120000</td>
      <td>4686.786917</td>
    </tr>
    <tr>
      <th>1</th>
      <td>49</td>
      <td>France</td>
      <td>Consumer Price Index, All items</td>
      <td>Value</td>
      <td>99.961667</td>
      <td>99.999167</td>
      <td>100.182500</td>
    </tr>
    <tr>
      <th>2</th>
      <td>216</td>
      <td>Bulgaria</td>
      <td>Consumer Price Index, All items</td>
      <td>Value</td>
      <td>6557.267697</td>
      <td>6550.406614</td>
      <td>6498.085301</td>
    </tr>
    <tr>
      <th>3</th>
      <td>421</td>
      <td>Colombia</td>
      <td>Consumer Price Index, All items</td>
      <td>Value</td>
      <td>116.754167</td>
      <td>122.580000</td>
      <td>131.790000</td>
    </tr>
    <tr>
      <th>4</th>
      <td>475</td>
      <td>Canada</td>
      <td>Consumer Price Index, All items</td>
      <td>Value</td>
      <td>125.158333</td>
      <td>126.566667</td>
      <td>128.375000</td>
    </tr>
  </tbody>
</table>
</div>




```python
cpi = cpi[["Country Name", "2015", "2016"]]
cpi.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Country Name</th>
      <th>2015</th>
      <th>2016</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Brazil</td>
      <td>4310.120000</td>
      <td>4686.786917</td>
    </tr>
    <tr>
      <th>1</th>
      <td>France</td>
      <td>99.999167</td>
      <td>100.182500</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Bulgaria</td>
      <td>6550.406614</td>
      <td>6498.085301</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Colombia</td>
      <td>122.580000</td>
      <td>131.790000</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Canada</td>
      <td>126.566667</td>
      <td>128.375000</td>
    </tr>
  </tbody>
</table>
</div>




```python
Final_happiness =  pd.merge(Final_happiness, cpi, on="Country Name", how = "inner")
Final_happiness.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Country Name</th>
      <th>Happiness Rank 2015</th>
      <th>Happiness Rank 2016</th>
      <th>Happiness Score 2015</th>
      <th>Happiness Score 2016</th>
      <th>GDP 2015</th>
      <th>GDP 2016</th>
      <th>Population 2015</th>
      <th>Population 2016</th>
      <th>GDP Per capita 2015</th>
      <th>GDP per capita 2016</th>
      <th>2015</th>
      <th>2016</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Switzerland</td>
      <td>1</td>
      <td>2</td>
      <td>7.587</td>
      <td>7.509</td>
      <td>6.790000e+11</td>
      <td>6.690000e+11</td>
      <td>8282396.0</td>
      <td>8372413.0</td>
      <td>81981.107882</td>
      <td>79905.279398</td>
      <td>100.617575</td>
      <td>100.180283</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Iceland</td>
      <td>2</td>
      <td>3</td>
      <td>7.561</td>
      <td>7.501</td>
      <td>1.694225e+10</td>
      <td>2.030410e+10</td>
      <td>330815.0</td>
      <td>335439.0</td>
      <td>51213.661333</td>
      <td>60529.926756</td>
      <td>239.815158</td>
      <td>243.876225</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Denmark</td>
      <td>3</td>
      <td>1</td>
      <td>7.527</td>
      <td>7.526</td>
      <td>3.010000e+11</td>
      <td>3.070000e+11</td>
      <td>5683483.0</td>
      <td>5728010.0</td>
      <td>52960.482155</td>
      <td>53596.275146</td>
      <td>100.000000</td>
      <td>100.250000</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Norway</td>
      <td>4</td>
      <td>4</td>
      <td>7.522</td>
      <td>7.498</td>
      <td>3.870000e+11</td>
      <td>3.710000e+11</td>
      <td>5190239.0</td>
      <td>5236151.0</td>
      <td>74563.040353</td>
      <td>70853.571641</td>
      <td>100.000000</td>
      <td>103.550000</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Canada</td>
      <td>5</td>
      <td>6</td>
      <td>7.427</td>
      <td>7.404</td>
      <td>1.560000e+12</td>
      <td>1.540000e+12</td>
      <td>35832513.0</td>
      <td>36264604.0</td>
      <td>43535.880389</td>
      <td>42465.650528</td>
      <td>126.566667</td>
      <td>128.375000</td>
    </tr>
  </tbody>
</table>
</div>




```python
Final_happiness = Final_happiness.rename(columns = {"2015":"CPI 2015", "2016":"CPI 2016"})
Final_happiness.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Country Name</th>
      <th>Happiness Rank 2015</th>
      <th>Happiness Rank 2016</th>
      <th>Happiness Score 2015</th>
      <th>Happiness Score 2016</th>
      <th>GDP 2015</th>
      <th>GDP 2016</th>
      <th>Population 2015</th>
      <th>Population 2016</th>
      <th>GDP Per capita 2015</th>
      <th>GDP per capita 2016</th>
      <th>CPI 2015</th>
      <th>CPI 2016</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Switzerland</td>
      <td>1</td>
      <td>2</td>
      <td>7.587</td>
      <td>7.509</td>
      <td>6.790000e+11</td>
      <td>6.690000e+11</td>
      <td>8282396.0</td>
      <td>8372413.0</td>
      <td>81981.107882</td>
      <td>79905.279398</td>
      <td>100.617575</td>
      <td>100.180283</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Iceland</td>
      <td>2</td>
      <td>3</td>
      <td>7.561</td>
      <td>7.501</td>
      <td>1.694225e+10</td>
      <td>2.030410e+10</td>
      <td>330815.0</td>
      <td>335439.0</td>
      <td>51213.661333</td>
      <td>60529.926756</td>
      <td>239.815158</td>
      <td>243.876225</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Denmark</td>
      <td>3</td>
      <td>1</td>
      <td>7.527</td>
      <td>7.526</td>
      <td>3.010000e+11</td>
      <td>3.070000e+11</td>
      <td>5683483.0</td>
      <td>5728010.0</td>
      <td>52960.482155</td>
      <td>53596.275146</td>
      <td>100.000000</td>
      <td>100.250000</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Norway</td>
      <td>4</td>
      <td>4</td>
      <td>7.522</td>
      <td>7.498</td>
      <td>3.870000e+11</td>
      <td>3.710000e+11</td>
      <td>5190239.0</td>
      <td>5236151.0</td>
      <td>74563.040353</td>
      <td>70853.571641</td>
      <td>100.000000</td>
      <td>103.550000</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Canada</td>
      <td>5</td>
      <td>6</td>
      <td>7.427</td>
      <td>7.404</td>
      <td>1.560000e+12</td>
      <td>1.540000e+12</td>
      <td>35832513.0</td>
      <td>36264604.0</td>
      <td>43535.880389</td>
      <td>42465.650528</td>
      <td>126.566667</td>
      <td>128.375000</td>
    </tr>
  </tbody>
</table>
</div>




```python
Final_happiness.to_csv("FinalHappiness.csv")
```


```python
data = dict(type = 'choropleth', 
           locations = Final_happiness['Country Name'],
           locationmode = 'country names',
           z = Final_happiness['GDP per capita 2016'], 
           text = Final_happiness['Country Name'],
           colorbar = {'title':'GDI in Thousands of Dollars'})
layout = dict(title = 'GDI Visualization', 
             geo = dict(showframe = False, 
                       projection = {'type': 'Mercator'}))
choromap3 = go.Figure(data = [data], layout=layout)
iplot(choromap3)
```


<div id="a9701e68-bb93-43de-8fc1-fde1ec3e35f2" style="height: 525px; width: 100%;" class="plotly-graph-div"></div><script type="text/javascript">require(["plotly"], function(Plotly) { window.PLOTLYENV=window.PLOTLYENV || {};window.PLOTLYENV.BASE_URL="https://plot.ly";Plotly.newPlot("a9701e68-bb93-43de-8fc1-fde1ec3e35f2", [{"type": "choropleth", "locations": ["Switzerland", "Iceland", "Denmark", "Norway", "Canada", "Netherlands", "Sweden", "New Zealand", "Australia", "Israel", "Costa Rica", "Austria", "Mexico", "United States", "Brazil", "Luxembourg", "Ireland", "Belgium", "United Kingdom", "Singapore", "Panama", "Germany", "Chile", "Qatar", "France", "Czech Republic", "Uruguay", "Colombia", "Thailand", "Saudi Arabia", "Spain", "Kuwait", "Guatemala", "Japan", "Bolivia", "Moldova", "Paraguay", "Kazakhstan", "Slovenia", "Lithuania", "Nicaragua", "Belarus", "Poland", "Malaysia", "Croatia", "Cyprus", "Algeria", "Mauritius", "Estonia", "Indonesia", "Turkey", "Nigeria", "Bhutan", "Jordan", "Montenegro", "Zambia", "Portugal", "Latvia", "Philippines", "Morocco", "Bosnia and Herzegovina", "Dominican Republic", "Mongolia", "Greece", "Hungary", "Honduras", "Tunisia", "Ukraine", "South Africa", "Ghana", "Zimbabwe", "Liberia", "India", "Nepal", "Ethiopia", "Sierra Leone", "Mauritania", "Kenya", "Georgia", "Malawi", "Sri Lanka", "Bulgaria", "Senegal", "Gabon", "Tanzania", "Rwanda", "Benin"], "locationmode": "country names", "z": [79905.27939794656, 60529.92675568434, 53596.27514616769, 70853.57164069562, 42465.65052799143, 45624.525772102614, 51798.407450908664, 39418.73348674678, 49564.63867027326, 37210.39082611748, 11824.638101947718, 44780.54156052285, 8232.684001683137, 57562.41499621235, 8668.312859540849, 100738.68422237266, 64213.54097255513, 41275.388332611896, 40399.07271169934, 52966.829032884554, 13680.236006919975, 42188.03541981375, 13791.367541955071, 59148.47980624203, 36925.07968604114, 18454.843175474707, 15220.566025146298, 5796.098317365939, 5910.241524996822, 20015.065829582498, 26675.539582165966, 27389.931954525804, 4146.74412863368, 38978.062603036444, 3104.9560891640817, 1900.2260882319986, 4077.7420726307255, 7699.052684954708, 21650.212755479064, 14912.686542680836, 2151.3820465865615, 4989.427763032791, 12404.501469801742, 9523.117849545319, 12149.189584052507, 17132.368998183956, 3915.672471679837, 9630.94402808766, 17736.80269571892, 3569.3023089372386, 10866.226116657539, 2177.540641511, 2773.5471348078695, 4087.9375166696595, 7028.934798643105, 1269.5735368163848, 19853.852402781013, 14071.027228370784, 2951.987462822138, 2948.114377539949, 4808.405425248293, 6722.223535798571, 3694.082552409693, 17919.281713484426, 12838.771623013316, 2361.1602045766717, 3688.646374699559, 2072.4633954784, 5266.40201717122, 1513.461034331951, 1029.0766486844072, 455.3707413570048, 1706.7277533025383, 729.122251492102, 706.757475118257, 505.2045112415987, 1101.9016265451573, 1455.3597653579795, 3865.7856932756163, 300.30766514247654, 3835.3948171013535, 7469.025246842584, 952.7683233566581, 7179.340661061347, 851.8660455251718, 702.8356016207415, 789.4404106657121], "text": ["Switzerland", "Iceland", "Denmark", "Norway", "Canada", "Netherlands", "Sweden", "New Zealand", "Australia", "Israel", "Costa Rica", "Austria", "Mexico", "United States", "Brazil", "Luxembourg", "Ireland", "Belgium", "United Kingdom", "Singapore", "Panama", "Germany", "Chile", "Qatar", "France", "Czech Republic", "Uruguay", "Colombia", "Thailand", "Saudi Arabia", "Spain", "Kuwait", "Guatemala", "Japan", "Bolivia", "Moldova", "Paraguay", "Kazakhstan", "Slovenia", "Lithuania", "Nicaragua", "Belarus", "Poland", "Malaysia", "Croatia", "Cyprus", "Algeria", "Mauritius", "Estonia", "Indonesia", "Turkey", "Nigeria", "Bhutan", "Jordan", "Montenegro", "Zambia", "Portugal", "Latvia", "Philippines", "Morocco", "Bosnia and Herzegovina", "Dominican Republic", "Mongolia", "Greece", "Hungary", "Honduras", "Tunisia", "Ukraine", "South Africa", "Ghana", "Zimbabwe", "Liberia", "India", "Nepal", "Ethiopia", "Sierra Leone", "Mauritania", "Kenya", "Georgia", "Malawi", "Sri Lanka", "Bulgaria", "Senegal", "Gabon", "Tanzania", "Rwanda", "Benin"], "colorbar": {"title": "GDI in Thousands of Dollars"}}], {"title": "GDI Visualization", "geo": {"showframe": false, "projection": {"type": "Mercator"}}}, {"showLink": true, "linkText": "Export to plot.ly"})});</script>



```python
data = dict(type = 'choropleth', 
           locations = Final_happiness['Country Name'],
           locationmode = 'country names',
           z = Final_happiness['GDP 2016'], 
           text = Final_happiness['Country Name'],
           colorbar = {'title':'GDP in Trillions'})
layout = dict(title = 'GDP Visualization', 
             geo = dict(showframe = False, 
                       projection = {'type': 'Mercator'}))
choromap3 = go.Figure(data = [data], layout=layout)


iplot(choromap3)
```


<div id="7ca77586-e01d-48f6-8147-caa76876efcf" style="height: 525px; width: 100%;" class="plotly-graph-div"></div><script type="text/javascript">require(["plotly"], function(Plotly) { window.PLOTLYENV=window.PLOTLYENV || {};window.PLOTLYENV.BASE_URL="https://plot.ly";Plotly.newPlot("7ca77586-e01d-48f6-8147-caa76876efcf", [{"type": "choropleth", "locations": ["Switzerland", "Iceland", "Denmark", "Norway", "Canada", "Netherlands", "Sweden", "New Zealand", "Australia", "Israel", "Costa Rica", "Austria", "Mexico", "United States", "Brazil", "Luxembourg", "Ireland", "Belgium", "United Kingdom", "Singapore", "Panama", "Germany", "Chile", "Qatar", "France", "Czech Republic", "Uruguay", "Colombia", "Thailand", "Saudi Arabia", "Spain", "Kuwait", "Guatemala", "Japan", "Bolivia", "Moldova", "Paraguay", "Kazakhstan", "Slovenia", "Lithuania", "Nicaragua", "Belarus", "Poland", "Malaysia", "Croatia", "Cyprus", "Algeria", "Mauritius", "Estonia", "Indonesia", "Turkey", "Nigeria", "Bhutan", "Jordan", "Montenegro", "Zambia", "Portugal", "Latvia", "Philippines", "Morocco", "Bosnia and Herzegovina", "Dominican Republic", "Mongolia", "Greece", "Hungary", "Honduras", "Tunisia", "Ukraine", "South Africa", "Ghana", "Zimbabwe", "Liberia", "India", "Nepal", "Ethiopia", "Sierra Leone", "Mauritania", "Kenya", "Georgia", "Malawi", "Sri Lanka", "Bulgaria", "Senegal", "Gabon", "Tanzania", "Rwanda", "Benin"], "locationmode": "country names", "z": [669000000000.0, 20304098101.0, 307000000000.0, 371000000000.0, 1540000000000.0, 777000000000.0, 514000000000.0, 185000000000.0, 1200000000000.0, 318000000000.0, 57435507212.0, 391000000000.0, 1050000000000.0, 18600000000000.0, 1800000000000.0, 58631324559.0, 305000000000.0, 468000000000.0, 2650000000000.0, 297000000000.0, 55187700000.0, 3480000000000.0, 247000000000.0, 152000000000.0, 2470000000000.0, 195000000000.0, 52419720714.0, 282000000000.0, 407000000000.0, 646000000000.0, 1240000000000.0, 111000000000.0, 68763255964.0, 4950000000000.0, 33806395514.0, 6749515655.0, 27424071383.0, 137000000000.0, 44708598649.0, 42773029835.0, 13230844687.0, 47407217531.0, 471000000000.0, 297000000000.0, 50714957391.0, 20047013274.0, 159000000000.0, 12168437744.0, 23337907619.0, 932000000000.0, 864000000000.0, 405000000000.0, 2212638830.0, 38654727746.0, 4374127212.0, 21063989683.0, 205000000000.0, 27572698482.0, 305000000000.0, 104000000000.0, 16910277134.0, 71583553488.0, 11183458131.0, 193000000000.0, 126000000000.0, 21516938910.0, 42062549395.0, 93270479389.0, 295000000000.0, 42689783734.0, 16619960402.0, 2101000000.0, 2260000000000.0, 21131983246.0, 72374224249.0, 3736588554.0, 4739298730.0, 70529014778.0, 14378016729.0, 5433038647.0, 81321876307.0, 53237882473.0, 14683697631.0, 14213558130.0, 47340071107.0, 8376048905.0, 8583031398.0], "text": ["Switzerland", "Iceland", "Denmark", "Norway", "Canada", "Netherlands", "Sweden", "New Zealand", "Australia", "Israel", "Costa Rica", "Austria", "Mexico", "United States", "Brazil", "Luxembourg", "Ireland", "Belgium", "United Kingdom", "Singapore", "Panama", "Germany", "Chile", "Qatar", "France", "Czech Republic", "Uruguay", "Colombia", "Thailand", "Saudi Arabia", "Spain", "Kuwait", "Guatemala", "Japan", "Bolivia", "Moldova", "Paraguay", "Kazakhstan", "Slovenia", "Lithuania", "Nicaragua", "Belarus", "Poland", "Malaysia", "Croatia", "Cyprus", "Algeria", "Mauritius", "Estonia", "Indonesia", "Turkey", "Nigeria", "Bhutan", "Jordan", "Montenegro", "Zambia", "Portugal", "Latvia", "Philippines", "Morocco", "Bosnia and Herzegovina", "Dominican Republic", "Mongolia", "Greece", "Hungary", "Honduras", "Tunisia", "Ukraine", "South Africa", "Ghana", "Zimbabwe", "Liberia", "India", "Nepal", "Ethiopia", "Sierra Leone", "Mauritania", "Kenya", "Georgia", "Malawi", "Sri Lanka", "Bulgaria", "Senegal", "Gabon", "Tanzania", "Rwanda", "Benin"], "colorbar": {"title": "GDP in Trillions"}}], {"title": "GDP Visualization", "geo": {"showframe": false, "projection": {"type": "Mercator"}}}, {"showLink": true, "linkText": "Export to plot.ly"})});</script>



```python
# print the bubble plot
fig, ax = plt.subplots()

ax.scatter(Final_happiness['Happiness Score 2015'], Final_happiness['GDP Per capita 2015'], color='pink', edgecolor='k')
ax.plot([], [], 'o', color='pink')
ax.scatter(Final_happiness['Happiness Score 2016'], Final_happiness['GDP per capita 2016'], color='black', edgecolor='k')
ax.plot([], [], 'o', color='black')

plt.savefig('GDP_per_cap_vs_Happiness.png')
plt.xlabel('Happiness Score')
plt.ylabel('GDP Per Capita')
plt.title("GDP vs Happiness")

#plt.legend( scatterpoints = 1, frameon=True,labelspacing=1, ncol = 1, title='City Type')

plt.show()
```


![png](output_21_0.png)



```python
# print the bubble plot
fig, ax = plt.subplots()

ax.scatter(Final_happiness['Happiness Score 2015'], Final_happiness['CPI 2015'], color='pink', edgecolor='k')
ax.plot([], [], 'o', color='pink')
ax.scatter(Final_happiness['Happiness Score 2016'], Final_happiness['CPI 2016'], color='black', edgecolor='k')
ax.plot([], [], 'o', color='black')

plt.savefig('CPI_vs_Happiness.png')
plt.xlabel('Happiness Score')
plt.ylabel('CPI')
plt.title("CPI vs. Happiness")
plt.ylim(0,1000)

#plt.legend( scatterpoints = 1, frameon=True,labelspacing=1, ncol = 1, title='City Type')

plt.show()
```


![png](output_22_0.png)



```python
# print the bubble plot
fig, ax = plt.subplots()

ax.scatter(Final_happiness['Happiness Score 2015'], Final_happiness['Population 2015'], color='pink', edgecolor='k')
ax.plot([], [], 'o', color='pink')
ax.scatter(Final_happiness['Happiness Score 2016'], Final_happiness['Population 2016'], color='black', edgecolor='k')
ax.plot([], [], 'o', color='black')

plt.savefig('Population_vs_Happiness.png')
plt.xlabel('Happiness Score')
plt.ylabel('Population x 10^8')
plt.title("Population vs. Happiness")
plt.ylim(0,100000000)

#plt.legend( scatterpoints = 1, frameon=True,labelspacing=1, ncol = 1, title='City Type')

plt.show()
```


![png](output_23_0.png)



```python
# print the bubble plot
fig, ax = plt.subplots()

ax.scatter(Final_happiness['Happiness Score 2015'], Final_happiness['GDP 2015'], color='pink', edgecolor='k')
ax.plot([], [], 'o', color='pink')
ax.scatter(Final_happiness['Happiness Score 2016'], Final_happiness['GDP 2016'], color='black', edgecolor='k')
ax.plot([], [], 'o', color='black')

plt.savefig('GDP_vs_Happiness.png')
plt.xlabel('Happiness Score')
plt.ylabel('GDP / 10^11')
plt.title("GDP vs. Happiness")
plt.ylim(0,100000000000)

#plt.legend( scatterpoints = 1, frameon=True,labelspacing=1, ncol = 1, title='City Type')

plt.show()
```


![png](output_24_0.png)

